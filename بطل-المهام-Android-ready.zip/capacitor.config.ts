import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.batalmahammat.dailycompanion',
  appName: 'بطل المهام - رفيق الأطفال اليومي',
  webDir: 'dist',
  bundledWebRuntime: false,
  android: {
    backgroundColor: '#ffffff',
  },
};

export default config;
