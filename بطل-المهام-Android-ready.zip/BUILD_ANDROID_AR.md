# تحويل التطبيق إلى APK لأندرويد

المشروع الأصلي من Google AI Studio هو تطبيق React/Vite، وتمت إضافة إعدادات Capacitor له.

## الطريقة الأسهل باستخدام GitHub

1. أنشئ Repository جديد على GitHub.
2. ارفع ملفات هذا المشروع إليه.
3. تأكد أن الفرع اسمه `main`.
4. افتح تبويب **Actions**.
5. شغّل Workflow باسم **Build Android APK** من زر **Run workflow**.
6. بعد انتهاء العملية، افتح الـ workflow ثم قسم **Artifacts**.
7. حمّل `batal-mahamat-debug-apk`.
8. فك الضغط عن الملف وستجد `app-debug.apk`.
9. انقل APK إلى هاتف Android وثبّته.

## بناء APK على الكمبيوتر

المتطلبات: Node.js 22+ وAndroid Studio/Android SDK.

```bash
npm install
npm run android:apk
```

سيكون الملف الناتج هنا:

`android/app/build/outputs/apk/debug/app-debug.apk`

## ملاحظة مهمة

نسخة APK التجريبية (Debug) مناسبة للتثبيت على الهاتف. للنشر على Google Play نحتاج لاحقًا إنشاء نسخة Release موقعة (AAB/APK) بمفتاح توقيع خاص.
