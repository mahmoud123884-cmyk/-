/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  AppState, 
  ChildProfile, 
  DailyTask, 
  HomeworkItem, 
  HomeworkStatus, 
  RewardItem, 
  SurahStatus 
} from './types';
import { loadAppState, saveAppState } from './utils/storage';
import { DailyTasksView } from './components/DailyTasksView';
import { HomeworkView } from './components/HomeworkView';
import { QuranTrackerView } from './components/QuranTrackerView';
import { RewardsStoreView } from './components/RewardsStoreView';
import { ParentDashboard } from './components/ParentDashboard';
import { StudyTimerModal } from './components/StudyTimerModal';
import { ParentGateModal } from './components/ParentGateModal';
import { 
  Sparkles, 
  Calendar, 
  BookOpen, 
  Gift, 
  ShieldCheck, 
  Volume2, 
  VolumeX, 
  Star, 
  CheckCircle2, 
  Timer, 
  Flame,
  Award,
  ChevronDown
} from 'lucide-react';
import { playStarChime, playSuccessFanfare, triggerConfetti } from './utils/soundEffects';

type NavTab = 'daily_tasks' | 'homework' | 'quran' | 'rewards';

export default function App() {
  const [appState, setAppState] = useState<AppState>(() => loadAppState());
  const [activeTab, setActiveTab] = useState<NavTab>('daily_tasks');
  const [isParentMode, setIsParentMode] = useState<boolean>(false);
  const [isParentGateOpen, setIsParentGateOpen] = useState<boolean>(false);
  
  // Study Timer Modal State
  const [isTimerOpen, setIsTimerOpen] = useState<boolean>(false);
  const [timerTitle, setTimerTitle] = useState<string>('جلسة تركيز');

  // Sync to LocalStorage on changes
  useEffect(() => {
    saveAppState(appState);
  }, [appState]);

  const activeChild: ChildProfile = 
    appState.children.find((c) => c.id === appState.activeChildId) || appState.children[0];

  // Handlers for Child Switching
  const handleSelectChild = (childId: string) => {
    setAppState((prev) => ({
      ...prev,
      activeChildId: childId
    }));
    playStarChime(appState.soundEnabled);
  };

  // Toggle Sound
  const toggleSound = () => {
    setAppState((prev) => ({
      ...prev,
      soundEnabled: !prev.soundEnabled
    }));
  };

  // Daily Task Toggle
  const handleToggleTask = (taskId: string) => {
    const today = new Date().toISOString().split('T')[0];

    setAppState((prev) => {
      const activeId = prev.activeChildId;
      let shouldPlayFanfare = false;

      const updatedChildren = prev.children.map((c) => {
        if (c.id !== activeId) return c;

        const task = c.tasks.find((t) => t.id === taskId);
        if (!task) return c;

        const newCompleted = !task.completed;
        const starDelta = newCompleted ? task.starsReward : -task.starsReward;

        const updatedTasks = c.tasks.map((t) =>
          t.id === taskId ? { ...t, completed: newCompleted } : t
        );

        // Calculate if all tasks are completed
        const allDone = updatedTasks.every((t) => t.completed);
        let newStreak = c.streakDays;

        if (allDone && c.lastCompletedDate !== today) {
          newStreak += 1;
          shouldPlayFanfare = true;
        }

        return {
          ...c,
          tasks: updatedTasks,
          stars: Math.max(0, c.stars + starDelta),
          streakDays: newStreak,
          lastCompletedDate: allDone ? today : c.lastCompletedDate
        };
      });

      if (shouldPlayFanfare && prev.soundEnabled) {
        playSuccessFanfare(true);
      }

      return {
        ...prev,
        children: updatedChildren
      };
    });
  };

  // Homework Status Update
  const handleUpdateHomeworkStatus = (id: string, newStatus: HomeworkStatus) => {
    setAppState((prev) => {
      const activeId = prev.activeChildId;
      return {
        ...prev,
        children: prev.children.map((c) => {
          if (c.id !== activeId) return c;

          const item = c.homework.find((h) => h.id === id);
          if (!item) return c;

          const wasDone = item.status === 'done';
          const isNowDone = newStatus === 'done';
          const starDelta = isNowDone && !wasDone ? item.starsReward : !isNowDone && wasDone ? -item.starsReward : 0;

          const updatedHomework = c.homework.map((h) =>
            h.id === id ? { ...h, status: newStatus } : h
          );

          return {
            ...c,
            homework: updatedHomework,
            stars: Math.max(0, c.stars + starDelta)
          };
        })
      };
    });
  };

  // Add Homework
  const handleAddHomework = (item: Omit<HomeworkItem, 'id'>) => {
    const newItem: HomeworkItem = {
      ...item,
      id: `hw_${Date.now()}`
    };

    setAppState((prev) => {
      const activeId = prev.activeChildId;
      return {
        ...prev,
        children: prev.children.map((c) => {
          if (c.id !== activeId) return c;
          return {
            ...c,
            homework: [newItem, ...c.homework]
          };
        })
      };
    });
  };

  // Quran Surah Progress Update (atomic updates for surah status and stars)
  const handleUpdateSurah = (
    surahNumber: number, 
    status: SurahStatus, 
    memorizedAyahs: number, 
    starsEarned: number = 0
  ) => {
    setAppState((prev) => {
      const activeId = prev.activeChildId;
      return {
        ...prev,
        children: prev.children.map((c) => {
          if (c.id !== activeId) return c;

          return {
            ...c,
            stars: Math.max(0, c.stars + starsEarned),
            quranProgress: {
              ...c.quranProgress,
              [surahNumber]: { status, memorizedAyahs }
            }
          };
        })
      };
    });
  };

  // Earn Stars directly (e.g. from Quran completion or focus timer)
  const handleEarnStars = (amount: number, _reason?: string) => {
    setAppState((prev) => {
      const activeId = prev.activeChildId;
      return {
        ...prev,
        children: prev.children.map((c) => {
          if (c.id !== activeId) return c;
          return {
            ...c,
            stars: Math.max(0, c.stars + amount)
          };
        })
      };
    });
  };

  // Claim Reward from Store
  const handleClaimReward = (reward: RewardItem) => {
    const today = new Date().toISOString().split('T')[0];
    const newClaim = {
      rewardId: reward.id,
      date: today,
      title: reward.title
    };

    setAppState((prev) => {
      const activeChild = prev.children.find((c) => c.id === prev.activeChildId) || prev.children[0];
      if (!activeChild || activeChild.stars < reward.costStars) return prev;

      const updatedRewards = prev.rewards.map((r) =>
        r.id === reward.id ? { ...r, claimedCount: r.claimedCount + 1 } : r
      );

      return {
        ...prev,
        rewards: updatedRewards,
        children: prev.children.map((c) => {
          if (c.id !== activeChild.id) return c;
          return {
            ...c,
            stars: Math.max(0, c.stars - reward.costStars),
            claimedRewards: [newClaim, ...c.claimedRewards]
          };
        })
      };
    });
  };

  // Open Timer
  const handleStartTimer = (title?: string) => {
    if (title) setTimerTitle(title);
    setIsTimerOpen(true);
    playStarChime(appState.soundEnabled);
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col font-sans pb-24 md:pb-12 text-slate-800">
      {/* Top Bar (Strict 3-zone contract from design constitution) */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-4 lg:px-8 py-3 transition-shadow">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-3">
          
          {/* Zone 1: Wordmark / Brand title */}
          <div className="flex items-center gap-2.5">
            <span className="text-2xl p-1.5 rounded-2xl bg-amber-100 flex items-center justify-center">
              🚀
            </span>
            <div className="leading-tight">
              <span className="text-lg font-black tracking-tight text-slate-900 block">
                بطل المهام
              </span>
              <span className="text-[10px] text-slate-400 font-bold hidden sm:block">
                رفيق الطفل لتنظيم اليوم والمذاكرة والقرآن
              </span>
            </div>
          </div>

          {/* Zone 2: Navigation Links (Text / Segmented tab buttons) */}
          <nav className="hidden md:flex items-center gap-1 p-1 bg-slate-100 rounded-2xl border border-slate-200/60">
            <button
              onClick={() => setActiveTab('daily_tasks')}
              className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'daily_tasks'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Calendar className="w-4 h-4 text-sky-500" />
              <span>المهام اليومية</span>
            </button>

            <button
              onClick={() => setActiveTab('homework')}
              className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'homework'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <BookOpen className="w-4 h-4 text-indigo-500" />
              <span>الواجبات والمذاكرة</span>
            </button>

            <button
              onClick={() => setActiveTab('quran')}
              className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'quran'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Award className="w-4 h-4 text-emerald-500" />
              <span>حفظ القرآن</span>
            </button>

            <button
              onClick={() => setActiveTab('rewards')}
              className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'rewards'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Gift className="w-4 h-4 text-amber-500" />
              <span>صندوق المكافآت</span>
            </button>
          </nav>

          {/* Zone 3: Primary Actions (Child selector + Stars + Sound + Parent Mode) */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Child Profile Selector */}
            <div className="relative flex items-center gap-1.5 p-1 rounded-2xl bg-slate-100 border border-slate-200/80">
              {appState.children.map((child) => (
                <button
                  key={child.id}
                  onClick={() => handleSelectChild(child.id)}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-bold transition-all ${
                    child.id === activeChild?.id
                      ? 'bg-white text-slate-900 shadow-sm scale-105'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                  title={`التبديل إلى ${child.name}`}
                >
                  <span className="text-base">{child.avatar}</span>
                  <span className="hidden sm:inline">{child.name}</span>
                </button>
              ))}
            </div>

            {/* Stars counter pill */}
            <div 
              onClick={() => setActiveTab('rewards')}
              className="cursor-pointer flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-700 font-bold text-xs shadow-xs hover:bg-amber-100 transition-all font-mono"
              title="رصيد النجوم الذهبية"
            >
              <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
              <span>{activeChild?.stars || 0}</span>
            </div>

            {/* Sound Toggle */}
            <button
              onClick={toggleSound}
              className="p-2 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors"
              title={appState.soundEnabled ? 'كتم المؤثرات الصوتية' : 'تشغيل الصوت والمؤثرات'}
            >
              {appState.soundEnabled ? (
                <Volume2 className="w-4 h-4 text-emerald-600" />
              ) : (
                <VolumeX className="w-4 h-4 text-slate-400" />
              )}
            </button>

            {/* Parent Mode Gate Trigger */}
            <button
              onClick={() => {
                if (isParentMode) {
                  setIsParentMode(false);
                } else {
                  setIsParentGateOpen(true);
                }
              }}
              className={`flex items-center gap-1 px-3 py-2 rounded-2xl text-xs font-bold transition-all ${
                isParentMode
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
              title="دخول لوحة تحكم ولي الأمر"
            >
              <ShieldCheck className="w-4 h-4" />
              <span className="hidden lg:inline">{isParentMode ? 'إغلاق وضع الوالدين' : 'ولي الأمر'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {isParentMode ? (
          <ParentDashboard
            appState={appState}
            onUpdateState={setAppState}
            onClose={() => setIsParentMode(false)}
            soundEnabled={appState.soundEnabled}
          />
        ) : (
          <>
            {activeTab === 'daily_tasks' && (
              <DailyTasksView
                tasks={activeChild?.tasks || []}
                onToggleTask={handleToggleTask}
                onOpenTimer={handleStartTimer}
                onOpenAddTask={() => setIsParentGateOpen(true)}
                soundEnabled={appState.soundEnabled}
                childName={activeChild?.name || 'البطل'}
                childAge={activeChild?.age || 7}
              />
            )}

            {activeTab === 'homework' && (
              <HomeworkView
                homework={activeChild?.homework || []}
                onUpdateStatus={handleUpdateHomeworkStatus}
                onAddHomework={handleAddHomework}
                onStartTimer={(title, minutes) => {
                  setTimerTitle(title);
                  setIsTimerOpen(true);
                }}
                soundEnabled={appState.soundEnabled}
                childName={activeChild?.name || 'البطل'}
              />
            )}

            {activeTab === 'quran' && (
              <QuranTrackerView
                progress={activeChild?.quranProgress || {}}
                onUpdateSurah={handleUpdateSurah}
                onEarnStars={handleEarnStars}
                soundEnabled={appState.soundEnabled}
                childName={activeChild?.name || 'البطل'}
              />
            )}

            {activeTab === 'rewards' && (
              <RewardsStoreView
                rewards={appState.rewards}
                currentStars={activeChild?.stars || 0}
                streakDays={activeChild?.streakDays || 1}
                claimedHistory={activeChild?.claimedRewards || []}
                onClaimReward={handleClaimReward}
                soundEnabled={appState.soundEnabled}
                childName={activeChild?.name || 'البطل'}
              />
            )}
          </>
        )}
      </main>

      {/* Mobile Fixed Bottom Navigation Bar (Natural thumb reach zone) */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/80 px-2 py-2">
        <div className="grid grid-cols-4 items-center">
          <button
            onClick={() => {
              setActiveTab('daily_tasks');
              setIsParentMode(false);
            }}
            className={`flex flex-col items-center justify-center py-1 transition-all ${
              activeTab === 'daily_tasks' && !isParentMode
                ? 'text-sky-600 font-bold scale-105'
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <Calendar className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] tracking-tight">المهام</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('homework');
              setIsParentMode(false);
            }}
            className={`flex flex-col items-center justify-center py-1 transition-all ${
              activeTab === 'homework' && !isParentMode
                ? 'text-indigo-600 font-bold scale-105'
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <BookOpen className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] tracking-tight">الواجبات</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('quran');
              setIsParentMode(false);
            }}
            className={`flex flex-col items-center justify-center py-1 transition-all ${
              activeTab === 'quran' && !isParentMode
                ? 'text-emerald-600 font-bold scale-105'
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <Award className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] tracking-tight">القرآن</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('rewards');
              setIsParentMode(false);
            }}
            className={`flex flex-col items-center justify-center py-1 transition-all ${
              activeTab === 'rewards' && !isParentMode
                ? 'text-amber-600 font-bold scale-105'
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <Gift className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] tracking-tight">الجوائز</span>
          </button>
        </div>
      </div>

      {/* Focus Timer Modal */}
      <StudyTimerModal
        isOpen={isTimerOpen}
        onClose={() => setIsTimerOpen(false)}
        taskTitle={timerTitle}
        soundEnabled={appState.soundEnabled}
        onSessionComplete={(minutes, starsEarned) => {
          handleEarnStars(starsEarned, `جلسة تركيز ومذاكرة (${minutes} دقيقة)`);
        }}
      />

      {/* Parent Gate Modal */}
      <ParentGateModal
        isOpen={isParentGateOpen}
        onClose={() => setIsParentGateOpen(false)}
        onSuccess={() => {
          setIsParentGateOpen(false);
          setIsParentMode(true);
          playStarChime(appState.soundEnabled);
        }}
        correctPin={appState.parentPin}
      />
    </div>
  );
}
