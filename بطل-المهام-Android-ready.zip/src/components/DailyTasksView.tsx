import React, { useState } from 'react';
import { DailyTask, TaskTimeOfDay } from '../types';
import { TaskIcon } from './TaskIcon';
import { Check, Star, Timer, Sparkles, PlusCircle } from 'lucide-react';
import { playStarChime, triggerConfetti, speakArabicPraise } from '../utils/soundEffects';

interface DailyTasksViewProps {
  tasks: DailyTask[];
  onToggleTask: (taskId: string) => void;
  onOpenTimer: (taskTitle?: string) => void;
  onOpenAddTask?: () => void;
  soundEnabled: boolean;
  childName: string;
  childAge: number;
}

export const DailyTasksView: React.FC<DailyTasksViewProps> = ({
  tasks,
  onToggleTask,
  onOpenTimer,
  onOpenAddTask,
  soundEnabled,
  childName,
  childAge
}) => {
  const [filter, setFilter] = useState<'all' | TaskTimeOfDay>('all');

  const filteredTasks = tasks.filter((t) => {
    if (filter === 'all') return true;
    return t.timeOfDay === filter;
  });

  const completedCount = tasks.filter((t) => t.completed).length;
  const totalCount = tasks.length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const handleToggle = (task: DailyTask) => {
    onToggleTask(task.id);
    if (!task.completed) {
      playStarChime(soundEnabled);
      triggerConfetti();
      if (Math.random() > 0.4) {
        speakArabicPraise(soundEnabled);
      }
    }
  };

  const getCategoryLabel = (cat: string) => {
    switch (cat) {
      case 'prayer_routine': return 'صلاة وعبادة';
      case 'study_homework': return 'مذاكرة وواجبات';
      case 'quran': return 'القرآن الكريم';
      case 'personal_habits': return 'عادات ونظافة';
      case 'helping_home': return 'مساعدة وترتيب';
      case 'fun_activity': return 'نشاط ومرح';
      default: return 'مهمة';
    }
  };

  return (
    <div className="space-y-6">
      {/* Hero Progress Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-sky-500 to-indigo-600 p-6 text-white shadow-xl shadow-sky-500/15">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="text-xl">🌟</span>
              <h2 className="text-xl font-bold tracking-tight">
                يومك المبارك يا {childName}
              </h2>
            </div>
            <p className="text-sm text-sky-100 max-w-lg">
              {progressPercent === 100
                ? 'ما شاء الله! أنجزت جميع مهام اليوم بنجاح باهر يا بطل!'
                : `لديك ${totalCount - completedCount} مهام متبقية اليوم. استمر بكل عزيمة ونشاط!`}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onOpenTimer('المذاكرة اليومية')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-white/20 hover:bg-white/30 backdrop-blur-md text-white text-xs font-bold transition-all border border-white/20"
            >
              <Timer className="w-4 h-4" />
              <span>ساعة التركيز</span>
            </button>

            {onOpenAddTask && (
              <button
                onClick={onOpenAddTask}
                className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-white text-sky-700 hover:bg-sky-50 text-xs font-bold shadow-md transition-all"
              >
                <PlusCircle className="w-4 h-4" />
                <span>إضافة مهمة</span>
              </button>
            )}
          </div>
        </div>

        {/* Progress Bar */}
        <div className="relative z-10 mt-5">
          <div className="flex items-center justify-between text-xs font-semibold mb-2">
            <span>معدل إنجاز المهام اليومية</span>
            <span className="font-mono tabular-nums">{completedCount} من {totalCount} ({progressPercent}%)</span>
          </div>
          <div className="h-3 w-full bg-white/20 rounded-full overflow-hidden p-0.5">
            <div
              className="h-full bg-amber-300 rounded-full transition-all duration-500 shadow-sm"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Decorative background circles */}
        <div className="absolute -top-12 -left-12 w-48 h-48 rounded-full bg-white/10 pointer-events-none" />
        <div className="absolute -bottom-16 -right-16 w-56 h-56 rounded-full bg-indigo-400/20 pointer-events-none" />
      </div>

      {/* Segmented Filter Control */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-1.5 p-1 bg-slate-100/80 rounded-2xl border border-slate-200/60 overflow-x-auto">
          {[
            { id: 'all', label: 'جميع المهام 📋' },
            { id: 'morning', label: 'الصباح 🌅' },
            { id: 'afternoon', label: 'الظهيرة والعصر ☀️' },
            { id: 'evening', label: 'المساء والنوم 🌙' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id as 'all' | TaskTimeOfDay)}
              className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
                filter === tab.id
                  ? 'bg-white text-slate-800 shadow-sm'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="text-xs text-slate-500 font-medium">
          <span>العمر الموصى به: {childAge} سنوات</span>
        </div>
      </div>

      {/* Tasks Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {filteredTasks.map((task) => (
          <div
            key={task.id}
            className={`group relative flex items-start justify-between p-4 rounded-3xl border transition-all duration-200 ${
              task.completed
                ? 'bg-emerald-50/70 border-emerald-200/70 text-slate-700 shadow-sm'
                : 'bg-white border-slate-200/80 hover:border-sky-300 hover:shadow-md'
            }`}
          >
            {/* Task Info & Category */}
            <div className="flex items-start gap-3.5 flex-1 min-w-0 pr-1">
              <div
                className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 transition-transform group-hover:scale-105 ${
                  task.completed
                    ? 'bg-emerald-100 text-emerald-700'
                    : 'bg-sky-50 text-sky-600'
                }`}
              >
                <TaskIcon name={task.iconName} className="w-5 h-5" />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 text-[11px] text-slate-400 font-medium mb-0.5">
                  <span>{getCategoryLabel(task.category)}</span>
                  <span>·</span>
                  <span className="flex items-center text-amber-500 font-bold">
                    <Star className="w-3 h-3 fill-amber-400 text-amber-400 inline ml-0.5" />
                    +{task.starsReward}
                  </span>
                </div>

                <h3
                  className={`text-sm font-bold truncate ${
                    task.completed ? 'line-through text-slate-400' : 'text-slate-800'
                  }`}
                  title={task.title}
                >
                  {task.title}
                </h3>

                {task.description && (
                  <p className="text-xs text-slate-500 mt-1 line-clamp-1">
                    {task.description}
                  </p>
                )}
              </div>
            </div>

            {/* Checkmark Button */}
            <button
              onClick={() => handleToggle(task)}
              aria-label={task.completed ? 'إلغاء الإنجاز' : 'إتمام المهمة'}
              className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 mr-2 transition-all active:scale-90 ${
                task.completed
                  ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/25 ring-2 ring-emerald-300 ring-offset-1'
                  : 'bg-slate-100 text-slate-400 hover:bg-sky-100 hover:text-sky-600 border border-slate-200'
              }`}
            >
              {task.completed ? (
                <Check className="w-5 h-5 stroke-[2.5]" />
              ) : (
                <div className="w-3 h-3 rounded-full border-2 border-slate-300" />
              )}
            </button>
          </div>
        ))}
      </div>

      {filteredTasks.length === 0 && (
        <div className="text-center py-12 bg-white rounded-3xl border border-dashed border-slate-200">
          <Sparkles className="w-8 h-8 text-slate-300 mx-auto mb-2" />
          <p className="text-sm font-medium text-slate-500">لا توجد مهام في هذا التوقيت</p>
        </div>
      )}
    </div>
  );
};
