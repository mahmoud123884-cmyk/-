import React, { useState, useEffect, useRef } from 'react';
import { X, Play, Pause, RotateCcw, Sparkles, Award } from 'lucide-react';
import { playStarChime, playSuccessFanfare, triggerBigCelebration, speakArabicPraise } from '../utils/soundEffects';

interface StudyTimerModalProps {
  isOpen: boolean;
  onClose: () => void;
  taskTitle?: string;
  onSessionComplete?: (minutes: number, starsEarned: number) => void;
  soundEnabled: boolean;
}

export const StudyTimerModal: React.FC<StudyTimerModalProps> = ({
  isOpen,
  onClose,
  taskTitle = 'جلسة مذاكرة وتركيز',
  onSessionComplete,
  soundEnabled
}) => {
  const [selectedMinutes, setSelectedMinutes] = useState<number>(15);
  const [secondsLeft, setSecondsLeft] = useState<number>(15 * 60);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    if (isOpen) {
      setSecondsLeft(selectedMinutes * 60);
      setIsRunning(false);
      setIsCompleted(false);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
  }, [isOpen, selectedMinutes]);

  useEffect(() => {
    if (isRunning) {
      timerRef.current = window.setInterval(() => {
        setSecondsLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            setIsRunning(false);
            setIsCompleted(true);
            handleFinish();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning]);

  const handleFinish = () => {
    playSuccessFanfare(soundEnabled);
    triggerBigCelebration();
    speakArabicPraise(soundEnabled);
    if (onSessionComplete) {
      const stars = selectedMinutes >= 20 ? 3 : selectedMinutes >= 10 ? 2 : 1;
      onSessionComplete(selectedMinutes, stars);
    }
  };

  const handlePresetSelect = (mins: number) => {
    setSelectedMinutes(mins);
    setSecondsLeft(mins * 60);
    setIsRunning(false);
    setIsCompleted(false);
    playStarChime(soundEnabled);
  };

  const handleReset = () => {
    setIsRunning(false);
    setIsCompleted(false);
    setSecondsLeft(selectedMinutes * 60);
  };

  const toggleRun = () => {
    setIsRunning((prev) => !prev);
    playStarChime(soundEnabled);
  };

  if (!isOpen) return null;

  const totalSecs = selectedMinutes * 60;
  const progressPercent = ((totalSecs - secondsLeft) / totalSecs) * 100;
  const mins = Math.floor(secondsLeft / 60);
  const secs = secondsLeft % 60;

  // Visual stroke calculation for SVG circle
  const radius = 90;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-pop">
      <div className="relative w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-slate-100 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-100 text-amber-600">
              <Sparkles className="w-5 h-5" />
            </span>
            <div>
              <h3 className="text-lg font-bold text-slate-900">ساعة التركيز والمذاكرة</h3>
              <p className="text-xs text-slate-500">{taskTitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex flex-col items-center py-6">
          {/* Preset Buttons */}
          <div className="flex items-center gap-2 mb-6">
            {[
              { min: 5, label: '5 دقائق (سريعة)' },
              { min: 10, label: '10 دقائق (صغار)' },
              { min: 15, label: '15 دقيقة (مذاكرة)' },
              { min: 25, label: '25 دقيقة (تركيز)' }
            ].map((preset) => (
              <button
                key={preset.min}
                onClick={() => handlePresetSelect(preset.min)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-all ${
                  selectedMinutes === preset.min
                    ? 'bg-amber-500 text-white shadow-md shadow-amber-500/20 scale-105'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {preset.label}
              </button>
            ))}
          </div>

          {/* Circle Timer */}
          <div className="relative w-56 h-56 flex items-center justify-center my-2">
            <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 200 200">
              {/* Background ring */}
              <circle
                cx="100"
                cy="100"
                r={radius}
                className="text-slate-100 stroke-current"
                strokeWidth="12"
                fill="transparent"
              />
              {/* Animated Progress ring */}
              <circle
                cx="100"
                cy="100"
                r={radius}
                className={`stroke-current transition-all duration-500 ${
                  isCompleted ? 'text-emerald-500' : isRunning ? 'text-amber-500' : 'text-sky-500'
                }`}
                strokeWidth="12"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                fill="transparent"
              />
            </svg>

            {/* Time Display */}
            <div className="absolute flex flex-col items-center justify-center">
              {isCompleted ? (
                <div className="text-center animate-pop">
                  <span className="text-4xl">🎉</span>
                  <div className="text-lg font-bold text-emerald-600 mt-1">رائع يا بطل!</div>
                  <div className="text-xs text-slate-500 font-medium">+3 نجوم ذهبية ⭐</div>
                </div>
              ) : (
                <>
                  <span className="text-4xl font-extrabold text-slate-800 font-mono tabular-nums">
                    {String(mins).padStart(2, '0')}:{String(secs).padStart(2, '0')}
                  </span>
                  <span className="text-xs text-slate-400 mt-1 font-medium">
                    {isRunning ? 'أنت تركز بذكاء...' : 'جاهز للبدء؟'}
                  </span>
                </>
              )}
            </div>
          </div>

          {/* Motivational phrase */}
          <p className="text-xs text-slate-500 text-center max-w-xs mt-2 px-2">
            {isCompleted
              ? 'أتممت وقتك بامتياز! بارك الله فيك وحفظك دائماً.'
              : isRunning
              ? 'التركيز سر التفوق والنجاح! لا تنشغل بأي مشتتات حتى يدق الجرس.'
              : 'اضغط ابدأ وتفرغ لإنهاء واجبك بإتقان وهدوء.'}
          </p>

          {/* Controls */}
          <div className="flex items-center gap-4 mt-6">
            <button
              onClick={handleReset}
              className="p-3 rounded-2xl bg-slate-100 text-slate-600 hover:bg-slate-200 transition-colors"
              title="إعادة التعيين"
            >
              <RotateCcw className="w-5 h-5" />
            </button>

            {!isCompleted ? (
              <button
                onClick={toggleRun}
                className={`px-8 py-3.5 rounded-2xl text-white font-bold text-base flex items-center gap-2 shadow-lg transition-all active:scale-95 ${
                  isRunning
                    ? 'bg-rose-500 hover:bg-rose-600 shadow-rose-500/25'
                    : 'bg-emerald-500 hover:bg-emerald-600 shadow-emerald-500/25'
                }`}
              >
                {isRunning ? (
                  <>
                    <Pause className="w-5 h-5" />
                    <span>إيقاف مؤقت</span>
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5 fill-current" />
                    <span>ابدأ التركيز</span>
                  </>
                )}
              </button>
            ) : (
              <button
                onClick={onClose}
                className="px-8 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-base flex items-center gap-2 shadow-lg shadow-emerald-600/25 transition-all"
              >
                <Award className="w-5 h-5" />
                <span>استلم النجوم وأغلق</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
