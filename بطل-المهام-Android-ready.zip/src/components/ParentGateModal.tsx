import React, { useState } from 'react';
import { Lock, X, ShieldAlert } from 'lucide-react';

interface ParentGateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  correctPin: string;
}

export const ParentGateModal: React.FC<ParentGateModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  correctPin
}) => {
  // We provide both PIN and an adult math challenge
  const [num1] = useState(7);
  const [num2] = useState(8);
  const [answer, setAnswer] = useState('');
  const [error, setError] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (Number(answer.trim()) === num1 * num2 || answer.trim() === correctPin) {
      setError(false);
      setAnswer('');
      onSuccess();
    } else {
      setError(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-pop">
      <div className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl border border-slate-100 text-center">
        <div className="flex items-center justify-between pb-2 mb-3">
          <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Lock className="w-5 h-5" />
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <h3 className="text-base font-bold text-slate-900 mb-1">منطقة أولياء الأمور</h3>
        <p className="text-xs text-slate-500 mb-4">
          يرجى حل المسألة للتأكد من أنك ولي الأمر:
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-center">
            <span className="text-2xl font-bold font-mono tracking-widest text-slate-800 dir-ltr inline-block">
              {num1} × {num2} = ؟
            </span>
          </div>

          <div>
            <input
              type="number"
              autoFocus
              placeholder="اكتب الناتج هنا أو الرمز السري"
              value={answer}
              onChange={(e) => {
                setAnswer(e.target.value);
                setError(false);
              }}
              className="w-full px-4 py-2.5 text-center text-sm font-bold rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            {error && (
              <p className="text-xs text-rose-500 font-bold mt-1">
                الإجابة غير صحيحة، حاول مجدداً!
              </p>
            )}
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-600/20 transition-all"
          >
            تأكيد الدخول
          </button>
        </form>
      </div>
    </div>
  );
};
