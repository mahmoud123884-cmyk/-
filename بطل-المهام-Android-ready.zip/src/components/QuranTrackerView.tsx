import React, { useState, useRef, useEffect } from 'react';
import { JUZ_AMMA_SURAHS, QuranSurahStatic } from '../data/quranData';
import { SurahStatus } from '../types';
import { 
  BookOpen, 
  Star, 
  CheckCircle2, 
  Play, 
  Pause, 
  Volume2, 
  Award, 
  X, 
  Check, 
  Sparkles,
  RotateCcw
} from 'lucide-react';
import { playStarChime, playSuccessFanfare, triggerBigCelebration, speakArabicPraise } from '../utils/soundEffects';

interface QuranTrackerViewProps {
  progress: Record<number, { status: SurahStatus; memorizedAyahs: number }>;
  onUpdateSurah: (surahNumber: number, status: SurahStatus, memorizedAyahs: number, starsEarned?: number) => void;
  onEarnStars: (amount: number, reason: string) => void;
  soundEnabled: boolean;
  childName: string;
}

function toArabicDigits(num: number): string {
  const digits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  return String(num).replace(/\d/g, (d) => digits[Number(d)]);
}

export const QuranTrackerView: React.FC<QuranTrackerViewProps> = ({
  progress,
  onUpdateSurah,
  soundEnabled,
  childName
}) => {
  const [filter, setFilter] = useState<'all' | 'mastered' | 'memorizing' | 'short_kids'>('all');
  const [activeSurah, setActiveSurah] = useState<QuranSurahStatic | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [celebrationNotice, setCelebrationNotice] = useState<string | null>(null);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Auto-dismiss celebration notice after 4 seconds
  useEffect(() => {
    if (!celebrationNotice) return;
    const timer = setTimeout(() => {
      setCelebrationNotice(null);
    }, 4500);
    return () => clearTimeout(timer);
  }, [celebrationNotice]);

  // Clean up audio on unmount
  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  // Compute overall stats
  const totalSurahs = JUZ_AMMA_SURAHS.length;
  let masteredCount = 0;
  let memorizingCount = 0;

  JUZ_AMMA_SURAHS.forEach((s) => {
    const p = progress[s.number]?.status || 'not_started';
    if (p === 'mastered') masteredCount++;
    else if (p === 'memorizing') memorizingCount++;
  });

  const completionPercent = Math.round((masteredCount / totalSurahs) * 100);

  const filteredSurahs = JUZ_AMMA_SURAHS.filter((s) => {
    const status = progress[s.number]?.status || 'not_started';
    if (filter === 'mastered') return status === 'mastered';
    if (filter === 'memorizing') return status === 'memorizing';
    if (filter === 'short_kids') return s.number >= 105 || s.number === 1; // Shortest for kids
    return true;
  });

  const openSurahReader = (surah: QuranSurahStatic) => {
    if (audioRef.current) {
      audioRef.current.pause();
      setIsPlayingAudio(false);
    }
    setActiveSurah(surah);
    playStarChime(soundEnabled);
  };

  const closeSurahReader = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      setIsPlayingAudio(false);
    }
    setActiveSurah(null);
  };

  const toggleAudio = (audioUrl?: string) => {
    if (!audioUrl) return;

    if (!audioRef.current) {
      audioRef.current = new Audio(audioUrl);
      audioRef.current.onended = () => setIsPlayingAudio(false);
      audioRef.current.onerror = () => setIsPlayingAudio(false);
    } else {
      if (audioRef.current.src !== audioUrl) {
        audioRef.current.src = audioUrl;
      }
    }

    if (isPlayingAudio) {
      audioRef.current.pause();
      setIsPlayingAudio(false);
    } else {
      audioRef.current.play().then(() => {
        setIsPlayingAudio(true);
      }).catch(() => {
        setIsPlayingAudio(false);
      });
    }
  };

  const handleSetStatus = (surah: QuranSurahStatic, newStatus: SurahStatus) => {
    const current = progress[surah.number];
    const prevStatus = current?.status || 'not_started';
    const ayahs = newStatus === 'mastered' ? surah.ayahCount : newStatus === 'not_started' ? 0 : current?.memorizedAyahs || 1;

    let starsDelta = 0;

    if (newStatus === 'mastered' && prevStatus !== 'mastered') {
      starsDelta = 5;
      playSuccessFanfare(soundEnabled);
      triggerBigCelebration();
      speakArabicPraise(soundEnabled);
      setCelebrationNotice(`ما شاء الله يا ${childName}! مبارك إتمام حفظ سورة ${surah.name} بامتياز! ⭐ حصلت على 5 نجوم`);
    } else if (newStatus === 'mastered' && prevStatus === 'mastered') {
      playStarChime(soundEnabled);
      setCelebrationNotice(`سورة ${surah.name} مسجلة كمنجزة بالفعل بامتياز ⭐`);
      return;
    } else if (prevStatus === 'mastered' && newStatus !== 'mastered') {
      starsDelta = -5;
      playStarChime(soundEnabled);
      setCelebrationNotice(`تم تغيير حالة سورة ${surah.name}`);
    } else if (newStatus === 'memorizing') {
      playStarChime(soundEnabled);
      setCelebrationNotice(`تم وضع سورة ${surah.name} في قائمة "قيد الحفظ" 📖`);
    } else {
      playStarChime(soundEnabled);
      setCelebrationNotice(null);
    }

    onUpdateSurah(surah.number, newStatus, ayahs, starsDelta);
  };

  const getStatusBadge = (status: SurahStatus) => {
    switch (status) {
      case 'mastered':
        return { label: 'أنجزت الحفظ ✅', color: 'bg-emerald-100 text-emerald-800 border-emerald-300 font-bold' };
      case 'memorizing':
        return { label: 'قيد الحفظ 📖', color: 'bg-amber-100 text-amber-800 border-amber-300 font-bold' };
      default:
        return { label: 'لم أبدأ بعد', color: 'bg-slate-100 text-slate-600 border-slate-200' };
    }
  };

  const activeProgress = activeSurah ? progress[activeSurah.number] : null;
  const currentStatus: SurahStatus = activeProgress?.status || 'not_started';

  return (
    <div className="space-y-6">
      {/* Quran Progress Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-600 to-teal-700 p-6 text-white shadow-xl shadow-emerald-600/15">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xl">🕌</span>
              <h2 className="text-xl font-bold tracking-tight">
                تاج الوقار - رحلة حفظ القرآن يا {childName}
              </h2>
            </div>
            <p className="text-sm text-emerald-100 max-w-lg">
              "خيركم من تعلّم القرآن وعلّمه" · اقرئي ورتّلي لتصعدي في درجات الجنة وتكسبي النجوم المباركة!
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-4 py-2.5 rounded-2xl bg-white/15 backdrop-blur-md border border-white/20 text-center">
              <span className="text-xs block text-emerald-100 font-medium">السور المنجزة</span>
              <span className="text-lg font-bold font-mono tabular-nums">{masteredCount} من {totalSurahs}</span>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="relative z-10 mt-5">
          <div className="flex items-center justify-between text-xs font-semibold mb-2">
            <span>نسبة إنجاز جزء عمّ والفاتحة</span>
            <span className="font-mono tabular-nums">{completionPercent}%</span>
          </div>
          <div className="h-3 w-full bg-white/20 rounded-full overflow-hidden p-0.5">
            <div
              className="h-full bg-amber-300 rounded-full transition-all duration-500"
              style={{ width: `${completionPercent}%` }}
            />
          </div>
        </div>

        <div className="absolute -top-12 -left-12 w-48 h-48 rounded-full bg-white/10 pointer-events-none" />
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-2xl border border-slate-200/60 overflow-x-auto">
          {[
            { id: 'all', label: 'جميع سور جزء عمّ' },
            { id: 'short_kids', label: 'القصار جداً (للبداية) 🐣' },
            { id: 'mastered', label: 'أنجزت الحفظ ✅' },
            { id: 'memorizing', label: 'قيد الحفظ 📖' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id as 'all' | 'mastered' | 'memorizing' | 'short_kids')}
              className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
                filter === tab.id
                  ? 'bg-white text-slate-800 shadow-sm'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="text-xs text-slate-500 font-medium">
          اضغط على أي سورة لقراءتها والاستماع إليها
        </div>
      </div>

      {/* Surahs Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {filteredSurahs.map((surah) => {
          const p = progress[surah.number] || { status: 'not_started', memorizedAyahs: 0 };
          const badge = getStatusBadge(p.status);
          const isMastered = p.status === 'mastered';
          const isMemorizing = p.status === 'memorizing';

          return (
            <div
              key={surah.number}
              onClick={() => openSurahReader(surah)}
              className={`group cursor-pointer p-4 rounded-3xl border transition-all text-center relative flex flex-col items-center justify-between min-h-[145px] active:scale-95 ${
                isMastered
                  ? 'bg-emerald-50/80 border-emerald-300 shadow-xs hover:shadow-md'
                  : isMemorizing
                  ? 'bg-amber-50/80 border-amber-300 hover:shadow-md'
                  : 'bg-white border-slate-200 hover:border-emerald-300 hover:shadow-md'
              }`}
            >
              {/* Surah Number pill & Quick Check Action */}
              <div className="w-full flex items-center justify-between text-[11px] text-slate-400 font-mono">
                <span className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center font-bold text-slate-600">
                  {surah.number}
                </span>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleSetStatus(surah, isMastered ? 'not_started' : 'mastered');
                  }}
                  className={`px-2 py-0.5 rounded-full text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
                    isMastered
                      ? 'bg-amber-100 text-amber-900 hover:bg-amber-200 shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-emerald-100 hover:text-emerald-800'
                  }`}
                  title={isMastered ? 'تم إنجاز الحفظ (انقر لتغيير الحالة)' : 'انقر لإنجاز الحفظ مباشرة (+5 نجوم)'}
                >
                  {isMastered ? (
                    <>
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                      <span className="text-[10px]">منجزة ⭐</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span className="text-[10px]">إنجاز</span>
                    </>
                  )}
                </button>
              </div>

              {/* Surah Name */}
              <div className="my-2">
                <h3 className="text-base font-bold text-slate-800 group-hover:text-emerald-700 transition-colors">
                  سورة {surah.name}
                </h3>
                <span className="text-[11px] text-slate-400 font-medium">
                  {surah.ayahCount} آيات
                </span>
              </div>

              {/* Status Badge */}
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-lg border ${badge.color}`}>
                {badge.label}
              </span>
            </div>
          );
        })}
      </div>

      {/* Surah Detail & Continuous Reader Modal */}
      {activeSurah && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-pop">
          <div className="w-full max-w-2xl max-h-[92vh] bg-white rounded-3xl shadow-2xl border border-slate-100 flex flex-col overflow-hidden">
            {/* Modal Header */}
            <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-100 bg-emerald-50/50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white font-bold flex items-center justify-center text-sm font-mono shadow-sm">
                  {activeSurah.number}
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900">
                    سورة {activeSurah.name}
                  </h3>
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <span>{activeSurah.ayahCount} آيات كريمة</span>
                    <span>·</span>
                    <span>جزء عمّ</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {activeSurah.audioUrl && (
                  <button
                    onClick={() => toggleAudio(activeSurah.audioUrl)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                      isPlayingAudio
                        ? 'bg-rose-500 text-white shadow-sm'
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm'
                    }`}
                  >
                    {isPlayingAudio ? (
                      <>
                        <Pause className="w-4 h-4 fill-current" />
                        <span>إيقاف الصوت</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 fill-current" />
                        <span>استماع للقارئ</span>
                      </>
                    )}
                  </button>
                )}

                <button
                  onClick={closeSurahReader}
                  className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
                  title="إغلاق"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Continuous Surah Mushaf Page */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-[#FAF7F0]/60">
              <div className="max-w-xl mx-auto bg-[#FEFCF6] border-2 border-amber-200/90 rounded-3xl p-6 sm:p-8 shadow-sm">
                
                {/* Ornamental Top Header */}
                <div className="flex items-center justify-center gap-3 mb-5">
                  <div className="h-[1px] flex-1 bg-gradient-to-r from-transparent via-amber-300 to-amber-500" />
                  <div className="flex items-center gap-2 px-4 py-1 rounded-full bg-amber-100/90 border border-amber-300 text-amber-900 font-bold text-xs sm:text-sm shadow-xs select-none">
                    <span>سورة {activeSurah.name}</span>
                    <span className="text-amber-500">·</span>
                    <span>{toArabicDigits(activeSurah.ayahCount)} آيات</span>
                  </div>
                  <div className="h-[1px] flex-1 bg-gradient-to-l from-transparent via-amber-300 to-amber-500" />
                </div>

                {/* Basmalah */}
                {activeSurah.number !== 9 && activeSurah.number !== 1 && (
                  <div className="font-quran text-2xl sm:text-3xl text-emerald-900 text-center py-2 mb-6 font-bold tracking-wide select-none">
                    بِسْمِ اللَّـهِ الرَّحْمَـٰنِ الرَّحِيمِ
                  </div>
                )}

                {/* Full Continuous Surah Text */}
                <div className="font-quran text-2xl sm:text-3xl text-slate-900 text-center leading-[2.6] sm:leading-[2.8] tracking-wide select-text">
                  {activeSurah.verses && activeSurah.verses.length > 0 ? (
                    activeSurah.verses.map((ayah, index) => (
                      <span key={index} className="inline">
                        <span>{ayah}</span>
                        <span className="inline-flex items-center justify-center w-7 h-7 mx-1.5 align-middle rounded-full border border-amber-400/90 bg-amber-50 text-amber-900 font-mono text-xs font-bold shadow-xs select-none">
                          {toArabicDigits(index + 1)}
                        </span>{' '}
                      </span>
                    ))
                  ) : (
                    <p className="text-base text-slate-500">جاري عرض الآيات الكريمة...</p>
                  )}
                </div>

                {/* Ornamental Bottom Footer */}
                <div className="flex items-center justify-center gap-3 mt-8">
                  <div className="h-[1px] flex-1 bg-gradient-to-r from-transparent via-amber-300 to-amber-500" />
                  <span className="text-xs text-amber-800/80 font-bold font-mono select-none">صدق الله العظيم</span>
                  <div className="h-[1px] flex-1 bg-gradient-to-l from-transparent via-amber-300 to-amber-500" />
                </div>
              </div>
            </div>

            {/* Actions Footer with the two requested buttons: "قيد الحفظ" and "أنجزت الحفظ" */}
            <div className="p-4 sm:p-5 border-t border-slate-200 bg-white space-y-3">
              {/* Celebration Banner */}
              {celebrationNotice && (
                <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-2xl text-emerald-900 text-xs sm:text-sm font-bold flex items-center justify-between animate-pop shadow-xs">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-amber-500 fill-amber-400 shrink-0" />
                    <span>{celebrationNotice}</span>
                  </div>
                  <button 
                    type="button"
                    onClick={() => setCelebrationNotice(null)}
                    className="text-emerald-700 hover:text-emerald-900 font-bold px-2 py-0.5 cursor-pointer text-xs"
                  >
                    ✕
                  </button>
                </div>
              )}

              {/* Status Indicator Banner */}
              <div className="flex items-center justify-between text-xs font-bold px-1">
                <span className="text-slate-500">حالة حفظ السورة:</span>
                {currentStatus === 'mastered' ? (
                  <span className="flex items-center gap-1.5 text-emerald-800 bg-emerald-100 px-3 py-1 rounded-xl border border-emerald-300 font-bold">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>تم إنجاز الحفظ بامتياز ⭐ (+5 نجوم)</span>
                  </span>
                ) : currentStatus === 'memorizing' ? (
                  <span className="flex items-center gap-1.5 text-amber-800 bg-amber-100 px-3 py-1 rounded-xl border border-amber-300 font-bold">
                    <BookOpen className="w-4 h-4 text-amber-600" />
                    <span>السورة قيد الحفظ حالياً 📖</span>
                  </span>
                ) : (
                  <span className="text-slate-400">لم يبدأ الحفظ بعد</span>
                )}
              </div>

              {/* The Two Main Action Buttons */}
              <div className="grid grid-cols-2 gap-3">
                {/* Button 1: قيد الحفظ */}
                <button
                  type="button"
                  onClick={() => handleSetStatus(activeSurah, 'memorizing')}
                  className={`py-3.5 px-4 rounded-2xl font-bold text-sm sm:text-base flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer ${
                    currentStatus === 'memorizing'
                      ? 'bg-amber-500 text-white shadow-lg shadow-amber-500/25 ring-2 ring-amber-300 ring-offset-1'
                      : 'bg-amber-50 hover:bg-amber-100 text-amber-800 border-2 border-amber-200'
                  }`}
                >
                  <BookOpen className="w-5 h-5" />
                  <span>{currentStatus === 'memorizing' ? '✓ قيد الحفظ حالياً' : 'قيد الحفظ'}</span>
                </button>

                {/* Button 2: أنجزت الحفظ */}
                <button
                  type="button"
                  onClick={() => handleSetStatus(activeSurah, 'mastered')}
                  className={`py-3.5 px-4 rounded-2xl font-bold text-sm sm:text-base flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer ${
                    currentStatus === 'mastered'
                      ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30 ring-2 ring-emerald-300 ring-offset-1'
                      : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-md shadow-emerald-600/20'
                  }`}
                >
                  <CheckCircle2 className="w-5 h-5 stroke-[2.5]" />
                  <span>{currentStatus === 'mastered' ? 'تم إنجاز الحفظ ✓' : 'أنجزت الحفظ ⭐'}</span>
                </button>
              </div>

              {/* Reset link if status is set */}
              {currentStatus !== 'not_started' && (
                <div className="text-center pt-1">
                  <button
                    type="button"
                    onClick={() => handleSetStatus(activeSurah, 'not_started')}
                    className="text-[11px] text-slate-400 hover:text-rose-600 underline cursor-pointer transition-colors"
                  >
                    إلغاء التحديد وتعيينها كـ "لم أبدأ بعد"
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
