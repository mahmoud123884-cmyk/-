import React from 'react';
import { 
  Sunrise, 
  Bed, 
  Sparkles, 
  Apple, 
  BookOpen, 
  Pencil, 
  Backpack, 
  Moon, 
  Flame, 
  Smile, 
  Box, 
  Palette, 
  Heart, 
  Star, 
  Clock, 
  CheckCircle2, 
  Trophy,
  Coffee,
  Glasses,
  Footprints,
  Music,
  Shirt
} from 'lucide-react';

interface TaskIconProps {
  name: string;
  className?: string;
}

export const TaskIcon: React.FC<TaskIconProps> = ({ name, className = 'w-6 h-6' }) => {
  switch (name) {
    case 'Sunrise': return <Sunrise className={className} />;
    case 'Bed': return <Bed className={className} />;
    case 'Sparkles': return <Sparkles className={className} />;
    case 'Apple': return <Apple className={className} />;
    case 'BookOpen': return <BookOpen className={className} />;
    case 'Pencil': return <Pencil className={className} />;
    case 'Backpack': return <Backpack className={className} />;
    case 'Moon': return <Moon className={className} />;
    case 'Flame': return <Flame className={className} />;
    case 'Smile': return <Smile className={className} />;
    case 'Box': return <Box className={className} />;
    case 'Palette': return <Palette className={className} />;
    case 'Heart': return <Heart className={className} />;
    case 'Clock': return <Clock className={className} />;
    case 'Trophy': return <Trophy className={className} />;
    case 'Coffee': return <Coffee className={className} />;
    case 'Glasses': return <Glasses className={className} />;
    case 'Footprints': return <Footprints className={className} />;
    case 'Music': return <Music className={className} />;
    case 'Shirt': return <Shirt className={className} />;
    default: return <Star className={className} />;
  }
};
