import React, { useState } from 'react';
import { AppState, ChildProfile, DailyTask, RewardItem, TaskCategory, TaskTimeOfDay } from '../types';
import { 
  ShieldCheck, 
  UserPlus, 
  Trash2, 
  Plus, 
  Star, 
  RotateCcw, 
  Settings, 
  CheckCircle, 
  AlertCircle,
  Gift,
  BookOpen,
  Award,
  Sparkles,
  Pencil,
  X
} from 'lucide-react';
import { playStarChime, triggerConfetti } from '../utils/soundEffects';

interface ParentDashboardProps {
  appState: AppState;
  onUpdateState: (newState: AppState) => void;
  onClose: () => void;
  soundEnabled: boolean;
}

export const ParentDashboard: React.FC<ParentDashboardProps> = ({
  appState,
  onUpdateState,
  onClose,
  soundEnabled
}) => {
  const [activeTab, setActiveTab] = useState<'tasks' | 'rewards' | 'children' | 'settings'>('tasks');
  const [selectedChildId, setSelectedChildId] = useState<string>(appState.activeChildId);

  // New Task form state
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskCategory, setNewTaskCategory] = useState<TaskCategory>('personal_habits');
  const [newTaskTime, setNewTaskTime] = useState<TaskTimeOfDay>('morning');
  const [newTaskStars, setNewTaskStars] = useState(1);
  const [newTaskIcon, setNewTaskIcon] = useState('Sparkles');

  // New Child form state
  const [newChildName, setNewChildName] = useState('');
  const [newChildAge, setNewChildAge] = useState(6);
  const [newChildAvatar, setNewChildAvatar] = useState('👧');

  // Edit Child state
  const [editingChildId, setEditingChildId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');
  const [editingAge, setEditingAge] = useState(6);
  const [editingAvatar, setEditingAvatar] = useState('👧');

  // New Reward form state
  const [newRewardTitle, setNewRewardTitle] = useState('');
  const [newRewardCost, setNewRewardCost] = useState(15);
  const [newRewardDesc, setNewRewardDesc] = useState('');

  const currentChild = appState.children.find((c) => c.id === selectedChildId) || appState.children[0];

  // Handlers
  const handleResetDailyTasks = () => {
    if (!currentChild) return;
    const updatedChildren = appState.children.map((c) => {
      if (c.id === currentChild.id) {
        return {
          ...c,
          tasks: c.tasks.map((t) => ({ ...t, completed: false }))
        };
      }
      return c;
    });
    onUpdateState({ ...appState, children: updatedChildren });
    playStarChime(soundEnabled);
  };

  const handleAdjustStars = (amount: number) => {
    if (!currentChild) return;
    const newStars = Math.max(0, currentChild.stars + amount);
    const updatedChildren = appState.children.map((c) => {
      if (c.id === currentChild.id) {
        return { ...c, stars: newStars };
      }
      return c;
    });
    onUpdateState({ ...appState, children: updatedChildren });
    playStarChime(soundEnabled);
  };

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim() || !currentChild) return;

    const newTask: DailyTask = {
      id: `task_${Date.now()}`,
      title: newTaskTitle.trim(),
      category: newTaskCategory,
      iconName: newTaskIcon,
      starsReward: newTaskStars,
      completed: false,
      timeOfDay: newTaskTime
    };

    const updatedChildren = appState.children.map((c) => {
      if (c.id === currentChild.id) {
        return {
          ...c,
          tasks: [...c.tasks, newTask]
        };
      }
      return c;
    });

    onUpdateState({ ...appState, children: updatedChildren });
    setNewTaskTitle('');
    playStarChime(soundEnabled);
  };

  const handleDeleteTask = (taskId: string) => {
    if (!currentChild) return;
    const updatedChildren = appState.children.map((c) => {
      if (c.id === currentChild.id) {
        return {
          ...c,
          tasks: c.tasks.filter((t) => t.id !== taskId)
        };
      }
      return c;
    });
    onUpdateState({ ...appState, children: updatedChildren });
  };

  const handleAddChild = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChildName.trim()) return;

    const newChild: ChildProfile = {
      id: `child_${Date.now()}`,
      name: newChildName.trim(),
      age: newChildAge,
      avatar: newChildAvatar,
      themeColor: newChildAvatar === '👧' ? 'rose' : 'sky',
      stars: 10,
      streakDays: 1,
      lastCompletedDate: new Date().toISOString().split('T')[0],
      tasks: [
        {
          id: `t_teeth_${Date.now()}`,
          title: 'تنظيف الأسنان صباحاً ومساءً',
          category: 'personal_habits',
          iconName: 'Sparkles',
          starsReward: 1,
          completed: false,
          timeOfDay: 'morning'
        },
        {
          id: `t_quran_${Date.now()}`,
          title: 'قراءة وسماع سورة الفاتحة والإخلاص',
          category: 'quran',
          iconName: 'BookOpen',
          starsReward: 2,
          completed: false,
          timeOfDay: 'afternoon'
        },
        {
          id: `t_toys_${Date.now()}`,
          title: 'ترتيب الألعاب في الغرفة',
          category: 'helping_home',
          iconName: 'Box',
          starsReward: 1,
          completed: false,
          timeOfDay: 'evening'
        }
      ],
      homework: [],
      quranProgress: {
        1: { status: 'mastered', memorizedAyahs: 7 },
        112: { status: 'mastered', memorizedAyahs: 4 }
      },
      claimedRewards: []
    };

    onUpdateState({
      ...appState,
      children: [...appState.children, newChild],
      activeChildId: newChild.id
    });

    setNewChildName('');
    triggerConfetti();
    playStarChime(soundEnabled);
  };

  const handleAddReward = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRewardTitle.trim()) return;

    const newReward: RewardItem = {
      id: `reward_${Date.now()}`,
      title: newRewardTitle.trim(),
      costStars: newRewardCost,
      icon: 'Gift',
      description: newRewardDesc.trim() || 'مكافأة مميزة للبطل',
      claimedCount: 0
    };

    onUpdateState({
      ...appState,
      rewards: [...appState.rewards, newReward]
    });

    setNewRewardTitle('');
    setNewRewardDesc('');
    playStarChime(soundEnabled);
  };

  const handleDeleteReward = (id: string) => {
    onUpdateState({
      ...appState,
      rewards: appState.rewards.filter((r) => r.id !== id)
    });
  };

  const handleStartEditChild = (child: ChildProfile) => {
    setEditingChildId(child.id);
    setEditingName(child.name);
    setEditingAge(child.age);
    setEditingAvatar(child.avatar);
  };

  const handleSaveEditChild = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingChildId || !editingName.trim()) return;

    const updatedChildren = appState.children.map((c) => {
      if (c.id === editingChildId) {
        return {
          ...c,
          name: editingName.trim(),
          age: editingAge,
          avatar: editingAvatar,
          themeColor: editingAvatar === '👧' ? 'rose' : 'sky'
        };
      }
      return c;
    });

    onUpdateState({
      ...appState,
      children: updatedChildren
    });

    setEditingChildId(null);
    playStarChime(soundEnabled);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-4 border-b border-slate-200 gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">لوحة تحكم ولي الأمر</h2>
            <p className="text-xs text-slate-500">إدارة مهام وجدول الأبناء وتخصيص المكافآت</p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="px-4 py-2 rounded-xl bg-slate-900 text-white hover:bg-slate-800 text-xs font-bold transition-all"
        >
          العودة لشاشة الأطفال 👧👦
        </button>
      </div>

      {/* Select active child to manage */}
      <div className="p-4 rounded-3xl bg-white border border-slate-200/80 shadow-sm flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <span className="text-xs font-bold text-slate-500">الطفل المحدد للإدارة:</span>
          <div className="flex items-center gap-2">
            {appState.children.map((child) => (
              <button
                key={child.id}
                onClick={() => setSelectedChildId(child.id)}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                  selectedChildId === child.id
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <span>{child.avatar}</span>
                <span>{child.name} ({child.age} سنين)</span>
              </button>
            ))}
          </div>
        </div>

        {/* Quick Child Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleResetDailyTasks}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors"
            title="تفريغ علامات الإنجاز لبدء يوم جديد"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>تصفير مهام اليوم</span>
          </button>

          <div className="flex items-center gap-1 bg-amber-50 px-2 py-1 rounded-xl border border-amber-200">
            <span className="text-xs font-bold text-amber-800 font-mono tabular-nums">{currentChild?.stars || 0} ⭐</span>
            <button
              onClick={() => handleAdjustStars(5)}
              className="px-1.5 py-0.5 rounded text-[11px] font-bold bg-amber-200 hover:bg-amber-300 text-amber-900"
              title="إضافة 5 نجوم تشجيعية"
            >
              +5
            </button>
            <button
              onClick={() => handleAdjustStars(-5)}
              className="px-1.5 py-0.5 rounded text-[11px] font-bold bg-amber-200 hover:bg-amber-300 text-amber-900"
              title="خصم 5 نجوم"
            >
              -5
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 p-1 bg-slate-100 rounded-2xl border border-slate-200/60 overflow-x-auto">
        {[
          { id: 'tasks', label: 'إدارة المهام اليومية 📋' },
          { id: 'rewards', label: 'إدارة المكافآت 🎁' },
          { id: 'children', label: 'إضافة وتعديل الأبناء 👨‍👩‍👧‍👦' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as 'tasks' | 'rewards' | 'children')}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
              activeTab === tab.id
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab: Tasks */}
      {activeTab === 'tasks' && currentChild && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* New Task Form */}
          <div className="p-5 rounded-3xl bg-white border border-slate-200/80 shadow-sm">
            <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
              <Plus className="w-4 h-4 text-indigo-600" />
              <span>إضافة مهمة جديدة لـ {currentChild.name}</span>
            </h3>

            <form onSubmit={handleAddTask} className="space-y-3 text-right">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">عنوان المهمة</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: شرب كوب الحليب كاملاً"
                  value={newTaskTitle}
                  onChange={(e) => setNewTaskTitle(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">القسم</label>
                <select
                  value={newTaskCategory}
                  onChange={(e) => setNewTaskCategory(e.target.value as TaskCategory)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="prayer_routine">صلاة وعبادة</option>
                  <option value="study_homework">مذاكرة وواجبات</option>
                  <option value="quran">حفظ القرآن الكريم</option>
                  <option value="personal_habits">عادات شخصية ونظافة</option>
                  <option value="helping_home">مساعدة وترتيب المنزل</option>
                  <option value="fun_activity">نشاط ومرح</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">التوقيت</label>
                  <select
                    value={newTaskTime}
                    onChange={(e) => setNewTaskTime(e.target.value as TaskTimeOfDay)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="morning">الصباح</option>
                    <option value="afternoon">الظهيرة والعصر</option>
                    <option value="evening">المساء والنوم</option>
                    <option value="anytime">أي وقت</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">النجوم الممنوحة</label>
                  <select
                    value={newTaskStars}
                    onChange={(e) => setNewTaskStars(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value={1}>1 نجمة ⭐</option>
                    <option value={2}>2 نجوم ⭐⭐</option>
                    <option value={3}>3 نجوم ⭐⭐⭐</option>
                    <option value={5}>5 نجوم 🌟</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">الأيقونة</label>
                <div className="grid grid-cols-6 gap-1.5 p-2 bg-slate-50 rounded-xl border border-slate-200">
                  {['Sunrise', 'Moon', 'Sparkles', 'Apple', 'BookOpen', 'Pencil', 'Bed', 'Smile', 'Box', 'Palette', 'Heart', 'Flame'].map((icon) => (
                    <button
                      type="button"
                      key={icon}
                      onClick={() => setNewTaskIcon(icon)}
                      className={`p-1.5 rounded-lg text-xs font-bold flex items-center justify-center transition-all ${
                        newTaskIcon === icon ? 'bg-indigo-600 text-white' : 'hover:bg-slate-200 text-slate-600'
                      }`}
                    >
                      {icon === 'Sunrise' && '🌅'}
                      {icon === 'Moon' && '🌙'}
                      {icon === 'Sparkles' && '✨'}
                      {icon === 'Apple' && '🍎'}
                      {icon === 'BookOpen' && '📖'}
                      {icon === 'Pencil' && '✏️'}
                      {icon === 'Bed' && '🛏️'}
                      {icon === 'Smile' && '😊'}
                      {icon === 'Box' && '📦'}
                      {icon === 'Palette' && '🎨'}
                      {icon === 'Heart' && '❤️'}
                      {icon === 'Flame' && '🔥'}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-600/20 transition-all"
              >
                إضافة المهمة للطفل
              </button>
            </form>
          </div>

          {/* Current Tasks List */}
          <div className="lg:col-span-2 p-5 rounded-3xl bg-white border border-slate-200/80 shadow-sm space-y-3">
            <h3 className="text-sm font-bold text-slate-900 mb-2">
              المهام الحالية لـ {currentChild.name} ({currentChild.tasks.length} مهام)
            </h3>

            <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
              {currentChild.tasks.map((task) => (
                <div
                  key={task.id}
                  className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-100 hover:border-slate-300 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-lg">
                      {task.iconName === 'Sunrise' ? '🌅' : task.iconName === 'Moon' ? '🌙' : '⭐'}
                    </span>
                    <div>
                      <h4 className="text-xs font-bold text-slate-800">{task.title}</h4>
                      <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                        <span>{task.timeOfDay === 'morning' ? 'صباحاً' : task.timeOfDay === 'afternoon' ? 'ظهراً' : 'مساءً'}</span>
                        <span>·</span>
                        <span className="text-amber-600 font-bold font-mono">+{task.starsReward} نجوم</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => handleDeleteTask(task.id)}
                    className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                    title="حذف المهمة"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab: Rewards */}
      {activeTab === 'rewards' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* New Reward Form */}
          <div className="p-5 rounded-3xl bg-white border border-slate-200/80 shadow-sm">
            <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
              <Gift className="w-4 h-4 text-amber-500" />
              <span>إضافة مكافأة جديدة لمتجر الجوائز</span>
            </h3>

            <form onSubmit={handleAddReward} className="space-y-3 text-right">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">اسم المكافأة</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: ركوب الدراجة في الحديقة"
                  value={newRewardTitle}
                  onChange={(e) => setNewRewardTitle(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">سعر النجوم المطلوب</label>
                <input
                  type="number"
                  min={5}
                  max={200}
                  step={5}
                  value={newRewardCost}
                  onChange={(e) => setNewRewardCost(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">الوصف أو التفاصيل</label>
                <input
                  type="text"
                  placeholder="مثال: مدة ساعة كاملة بعد صلاة العصر"
                  value={newRewardDesc}
                  onChange={(e) => setNewRewardDesc(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-md shadow-amber-500/20 transition-all"
              >
                إضافة المكافأة لمتجر الأبطال
              </button>
            </form>
          </div>

          {/* Current Rewards */}
          <div className="lg:col-span-2 p-5 rounded-3xl bg-white border border-slate-200/80 shadow-sm space-y-3">
            <h3 className="text-sm font-bold text-slate-900 mb-2">
              المكافآت المتاحة في المتجر ({appState.rewards.length})
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {appState.rewards.map((reward) => (
                <div
                  key={reward.id}
                  className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between"
                >
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">{reward.title}</h4>
                    <span className="text-[11px] text-amber-600 font-bold font-mono">
                      {reward.costStars} نجوم ⭐
                    </span>
                  </div>

                  <button
                    onClick={() => handleDeleteReward(reward.id)}
                    className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                    title="حذف المكافأة"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab: Children */}
      {activeTab === 'children' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* New Child Form */}
          <div className="p-5 rounded-3xl bg-white border border-slate-200/80 shadow-sm">
            <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
              <UserPlus className="w-4 h-4 text-emerald-600" />
              <span>إضافة طفل جديد للعائلة</span>
            </h3>

            <form onSubmit={handleAddChild} className="space-y-3 text-right">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">اسم الطفل</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: يوسف أو فاطمة"
                  value={newChildName}
                  onChange={(e) => setNewChildName(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">العمر (سنوات)</label>
                <select
                  value={newChildAge}
                  onChange={(e) => setNewChildAge(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  {[4, 5, 6, 7, 8, 9, 10].map((age) => (
                    <option key={age} value={age}>
                      {age} سنوات {age <= 6 ? '(مرحلة الروضة / الطفولة المبكرة)' : '(المرحلة الابتدائية)'}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">الصورة الرمزية (الرمز)</label>
                <div className="flex items-center gap-3">
                  {['👦', '👧', '🦁', '🚀', '🌟'].map((av) => (
                    <button
                      type="button"
                      key={av}
                      onClick={() => setNewChildAvatar(av)}
                      className={`text-2xl p-2 rounded-2xl border transition-all ${
                        newChildAvatar === av
                          ? 'bg-emerald-50 border-emerald-500 scale-110 shadow-sm'
                          : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {av}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/20 transition-all"
              >
                إضافة الطفل وتجهيز جدوله
              </button>
            </form>
          </div>

          {/* Children List */}
          <div className="lg:col-span-2 p-5 rounded-3xl bg-white border border-slate-200/80 shadow-sm space-y-3">
            <h3 className="text-sm font-bold text-slate-900 mb-2">
              ملفات أبطال العائلة ({appState.children.length})
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {appState.children.map((child) => (
                <div
                  key={child.id}
                  className="p-4 rounded-3xl bg-slate-50 border border-slate-200 flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-3xl p-2 rounded-2xl bg-white shadow-sm">{child.avatar}</span>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900">{child.name}</h4>
                      <p className="text-xs text-slate-500 font-medium">العمر: {child.age} سنوات</p>
                      <div className="flex items-center gap-2 text-[11px] text-amber-600 font-bold mt-1 font-mono">
                        <span>{child.stars} نجوم ⭐</span>
                        <span>·</span>
                        <span>{child.tasks.length} مهام</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleStartEditChild(child)}
                      className="p-2 rounded-xl text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 transition-colors"
                      title="تعديل اسم وبيانات الطفل"
                    >
                      <Pencil className="w-4 h-4" />
                    </button>

                    {appState.children.length > 1 && (
                      <button
                        onClick={() => {
                          const updated = appState.children.filter((c) => c.id !== child.id);
                          onUpdateState({
                            ...appState,
                            children: updated,
                            activeChildId: updated[0].id
                          });
                        }}
                        className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                        title="حذف الملف"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Edit Child Modal */}
      {editingChildId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-pop">
          <div className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl border border-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-base font-bold text-slate-900">تعديل بيانات الطفل</h3>
              <button
                onClick={() => setEditingChildId(null)}
                className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEditChild} className="space-y-4 text-right">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">اسم الطفل</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: كِندَة"
                  value={editingName}
                  onChange={(e) => setEditingName(e.target.value)}
                  className="w-full px-3 py-2 text-sm font-bold rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">العمر (سنوات)</label>
                <select
                  value={editingAge}
                  onChange={(e) => setEditingAge(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  {[4, 5, 6, 7, 8, 9, 10].map((age) => (
                    <option key={age} value={age}>
                      {age} سنوات {age <= 6 ? '(مرحلة الروضة / الطفولة المبكرة)' : '(المرحلة الابتدائية)'}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">الصورة الرمزية (الرمز)</label>
                <div className="flex items-center gap-3">
                  {['👧', '👦', '🦁', '🚀', '🌟', '🦄'].map((av) => (
                    <button
                      type="button"
                      key={av}
                      onClick={() => setEditingAvatar(av)}
                      className={`text-2xl p-2 rounded-2xl border transition-all ${
                        editingAvatar === av
                          ? 'bg-indigo-50 border-indigo-500 scale-110 shadow-sm'
                          : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {av}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingChildId(null)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-600/20 transition-all"
                >
                  حفظ التعديل
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
