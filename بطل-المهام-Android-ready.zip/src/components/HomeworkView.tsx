import React, { useState } from 'react';
import { HomeworkItem, HomeworkStatus } from '../types';
import { 
  BookOpen, 
  Clock, 
  Calendar, 
  Plus, 
  CheckCircle2, 
  Timer, 
  Star, 
  Check, 
  Hourglass,
  Layers
} from 'lucide-react';
import { playStarChime, triggerConfetti, speakArabicPraise } from '../utils/soundEffects';

interface HomeworkViewProps {
  homework: HomeworkItem[];
  onUpdateStatus: (id: string, newStatus: HomeworkStatus) => void;
  onAddHomework: (item: Omit<HomeworkItem, 'id'>) => void;
  onStartTimer: (title: string, minutes: number) => void;
  soundEnabled: boolean;
  childName: string;
}

const COMMON_SUBJECTS = [
  { name: 'الرياضيات', color: 'bg-blue-50 text-blue-700 border-blue-200' },
  { name: 'اللغة العربية', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  { name: 'العلوم', color: 'bg-teal-50 text-teal-700 border-teal-200' },
  { name: 'اللغة الإنجليزية', color: 'bg-purple-50 text-purple-700 border-purple-200' },
  { name: 'التربية الإسلامية', color: 'bg-amber-50 text-amber-700 border-amber-200' },
  { name: 'الدراسات الاجتماعية', color: 'bg-orange-50 text-orange-700 border-orange-200' },
  { name: 'الرسم والفنون', color: 'bg-rose-50 text-rose-700 border-rose-200' },
  { name: 'الحاسوب والتكنولوجيا', color: 'bg-cyan-50 text-cyan-700 border-cyan-200' },
];

export const HomeworkView: React.FC<HomeworkViewProps> = ({
  homework,
  onUpdateStatus,
  onAddHomework,
  onStartTimer,
  soundEnabled,
  childName
}) => {
  const [filter, setFilter] = useState<'all' | HomeworkStatus>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // New Homework Form State
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState(COMMON_SUBJECTS[0].name);
  const [dueDate, setDueDate] = useState('اليوم');
  const [estimatedMinutes, setEstimatedMinutes] = useState(20);
  const [starsReward, setStarsReward] = useState(2);
  const [notes, setNotes] = useState('');

  const filteredHomework = homework.filter((item) => {
    if (filter === 'all') return true;
    return item.status === filter;
  });

  const doneCount = homework.filter((h) => h.status === 'done').length;
  const inProgressCount = homework.filter((h) => h.status === 'in_progress').length;
  const todoCount = homework.filter((h) => h.status === 'todo').length;

  const handleStatusChange = (id: string, status: HomeworkStatus) => {
    onUpdateStatus(id, status);
    if (status === 'done') {
      playStarChime(soundEnabled);
      triggerConfetti();
      speakArabicPraise(soundEnabled);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const matchedSubject = COMMON_SUBJECTS.find((s) => s.name === subject) || COMMON_SUBJECTS[0];

    onAddHomework({
      title: title.trim(),
      subject,
      subjectColor: matchedSubject.color,
      dueDate,
      status: 'todo',
      estimatedMinutes,
      starsReward,
      notes: notes.trim() || undefined
    });

    setTitle('');
    setNotes('');
    setIsAddModalOpen(false);
    playStarChime(soundEnabled);
  };

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
        <div className="p-4 rounded-3xl bg-white border border-slate-200/80 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-medium">واجبات اليوم والمطلوبة</span>
            <div className="text-2xl font-bold text-slate-800 font-mono tabular-nums">{todoCount}</div>
          </div>
          <div className="w-11 h-11 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
            <Hourglass className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-3xl bg-white border border-slate-200/80 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-medium">قيد المذاكرة والحل</span>
            <div className="text-2xl font-bold text-sky-600 font-mono tabular-nums">{inProgressCount}</div>
          </div>
          <div className="w-11 h-11 rounded-2xl bg-sky-50 text-sky-600 flex items-center justify-center font-bold">
            <BookOpen className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-3xl bg-white border border-slate-200/80 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-medium">تم الإنجاز بنجاح ⭐</span>
            <div className="text-2xl font-bold text-emerald-600 font-mono tabular-nums">{doneCount}</div>
          </div>
          <div className="w-11 h-11 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Action & Filter Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-2xl border border-slate-200/60 overflow-x-auto">
          {[
            { id: 'all', label: 'الكل' },
            { id: 'todo', label: 'المطلوبة 📌' },
            { id: 'in_progress', label: 'قيد الحل ✏️' },
            { id: 'done', label: 'المنجزة ✅' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id as 'all' | HomeworkStatus)}
              className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
                filter === tab.id
                  ? 'bg-white text-slate-800 shadow-sm'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-600/20 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة واجب مدرسي</span>
        </button>
      </div>

      {/* Homework List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredHomework.map((item) => (
          <div
            key={item.id}
            className={`p-5 rounded-3xl border transition-all ${
              item.status === 'done'
                ? 'bg-emerald-50/50 border-emerald-200/60 opacity-90'
                : 'bg-white border-slate-200/80 hover:shadow-md hover:border-indigo-200'
            }`}
          >
            {/* Subject and Time Meta */}
            <div className="flex items-center justify-between gap-2 mb-3">
              <span className={`text-[11px] font-bold px-2.5 py-1 rounded-xl border ${item.subjectColor}`}>
                {item.subject}
              </span>

              <div className="flex items-center gap-2 text-xs text-slate-400 font-medium">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5" />
                  {item.dueDate}
                </span>
                <span>·</span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  {item.estimatedMinutes} دقيقة
                </span>
              </div>
            </div>

            {/* Title & Notes */}
            <h4
              className={`text-base font-bold mb-1.5 ${
                item.status === 'done' ? 'line-through text-slate-400' : 'text-slate-900'
              }`}
            >
              {item.title}
            </h4>

            {item.notes && (
              <p className="text-xs text-slate-500 mb-4 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                💡 {item.notes}
              </p>
            )}

            {/* Actions Bar */}
            <div className="flex items-center justify-between pt-3 border-t border-slate-100 mt-2">
              {/* Stars badge */}
              <div className="flex items-center gap-1 text-xs font-bold text-amber-500">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                <span>+{item.starsReward} نجوم</span>
              </div>

              {/* Status and Timer buttons */}
              <div className="flex items-center gap-2">
                {item.status !== 'done' && (
                  <button
                    onClick={() => onStartTimer(`${item.subject}: ${item.title}`, item.estimatedMinutes)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-700 text-xs font-bold transition-all border border-amber-200"
                    title="بدء مؤقت المذاكرة لهذا الواجب"
                  >
                    <Timer className="w-3.5 h-3.5" />
                    <span>مؤقت</span>
                  </button>
                )}

                {item.status === 'todo' && (
                  <button
                    onClick={() => handleStatusChange(item.id, 'in_progress')}
                    className="px-3 py-1.5 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-700 text-xs font-bold transition-all border border-sky-200"
                  >
                    بدء الحل
                  </button>
                )}

                {item.status === 'in_progress' && (
                  <button
                    onClick={() => handleStatusChange(item.id, 'done')}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm transition-all"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>تم الإنجاز</span>
                  </button>
                )}

                {item.status === 'done' && (
                  <button
                    onClick={() => handleStatusChange(item.id, 'todo')}
                    className="text-xs text-slate-400 hover:text-slate-600 underline"
                  >
                    إعادة للواجبات
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredHomework.length === 0 && (
        <div className="text-center py-12 bg-white rounded-3xl border border-dashed border-slate-200">
          <BookOpen className="w-8 h-8 text-slate-300 mx-auto mb-2" />
          <p className="text-sm font-medium text-slate-500">لا توجد واجبات في هذه القائمة</p>
        </div>
      )}

      {/* Add Homework Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-pop">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-base font-bold text-slate-900">إضافة واجب مدرسي جديد</h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold"
              >
                إلغاء
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-4 text-right">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">المادة الدراسية</label>
                <select
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  {COMMON_SUBJECTS.map((s) => (
                    <option key={s.name} value={s.name}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">عنوان الواجب أو رقم الصفحة</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: حل صفحة 35 في كتاب الرياضيات"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">موعد التسليم</label>
                  <select
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="اليوم">اليوم</option>
                    <option value="غداً">غداً</option>
                    <option value="بعد غد">بعد غد</option>
                    <option value="هذا الأسبوع">هذا الأسبوع</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">الوقت المتوقع (دقيقة)</label>
                  <input
                    type="number"
                    min={5}
                    max={120}
                    step={5}
                    value={estimatedMinutes}
                    onChange={(e) => setEstimatedMinutes(Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono tabular-nums"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">النجوم المكافئة</label>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 5].map((stars) => (
                    <button
                      type="button"
                      key={stars}
                      onClick={() => setStarsReward(stars)}
                      className={`flex-1 py-1.5 text-xs font-bold rounded-xl border transition-all ${
                        starsReward === stars
                          ? 'bg-amber-500 text-white border-amber-500 shadow-sm'
                          : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {stars} ⭐
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">ملاحظات إضافية (اختياري)</label>
                <input
                  type="text"
                  placeholder="ملاحظة أو تلميح يساعد البطل في الحل"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm shadow-md shadow-indigo-600/25 transition-all"
                >
                  حفظ الواجب في الجدول
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
