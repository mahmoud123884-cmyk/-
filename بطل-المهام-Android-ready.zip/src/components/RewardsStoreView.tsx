import React, { useState } from 'react';
import { RewardItem } from '../types';
import { 
  Gift, 
  Star, 
  Sparkles, 
  Check, 
  Trophy, 
  Flame, 
  History,
  Gamepad2,
  Utensils,
  Film,
  TreePine,
  IceCream
} from 'lucide-react';
import { playStarChime, playSuccessFanfare, triggerBigCelebration, speakArabicPraise } from '../utils/soundEffects';

interface RewardsStoreViewProps {
  rewards: RewardItem[];
  currentStars: number;
  streakDays: number;
  claimedHistory: { rewardId: string; date: string; title: string }[];
  onClaimReward: (reward: RewardItem) => void;
  soundEnabled: boolean;
  childName: string;
}

export const RewardsStoreView: React.FC<RewardsStoreViewProps> = ({
  rewards,
  currentStars,
  streakDays,
  claimedHistory,
  onClaimReward,
  soundEnabled,
  childName
}) => {
  const [selectedReward, setSelectedReward] = useState<RewardItem | null>(null);

  const getChildTitle = (stars: number) => {
    if (stars >= 100) return { title: 'البطل الخارق 🦸‍♂️', next: 'الدرجة القصوى' };
    if (stars >= 60) return { title: 'حافظ القرآن المتميز 🕌', next: `${100 - stars} نجمة للبطل الخارق` };
    if (stars >= 30) return { title: 'بطل المذاكرة والإتقان 🏆', next: `${60 - stars} نجمة لوسام الحافظ` };
    if (stars >= 15) return { title: 'نجم الالتزام اليومي 💫', next: `${30 - stars} نجمة لبطل المذاكرة` };
    return { title: 'بطل البداية الصغير 🌟', next: `${15 - stars} نجمة لنجم الالتزام` };
  };

  const currentLevel = getChildTitle(currentStars);

  const getRewardIcon = (iconName: string) => {
    switch (iconName) {
      case 'IceCream': return <IceCream className="w-6 h-6 text-pink-500" />;
      case 'Gamepad2': return <Gamepad2 className="w-6 h-6 text-purple-500" />;
      case 'Utensils': return <Utensils className="w-6 h-6 text-amber-500" />;
      case 'Film': return <Film className="w-6 h-6 text-blue-500" />;
      case 'TreePine': return <TreePine className="w-6 h-6 text-emerald-500" />;
      default: return <Gift className="w-6 h-6 text-rose-500" />;
    }
  };

  const handleClaim = (reward: RewardItem) => {
    if (currentStars < reward.costStars) return;
    onClaimReward(reward);
    setSelectedReward(null);
    playSuccessFanfare(soundEnabled);
    triggerBigCelebration();
    speakArabicPraise(soundEnabled);
  };

  return (
    <div className="space-y-6">
      {/* Stars Header Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 p-6 text-white shadow-xl shadow-amber-500/20">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="space-y-1">
            <span className="text-xs uppercase tracking-wider text-amber-100 font-bold">صندوق الجوائز والمكافآت</span>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 text-3xl font-extrabold font-mono tabular-nums">
                <Star className="w-8 h-8 fill-amber-200 text-amber-200 animate-wiggle" />
                <span>{currentStars}</span>
              </div>
              <span className="text-lg font-bold">نجمة ذهبية</span>
            </div>
            <p className="text-xs text-amber-100">
              المستوى الحالي: <strong className="text-white font-bold">{currentLevel.title}</strong>
            </p>
          </div>

          <div className="flex items-center gap-4 bg-white/20 backdrop-blur-md px-5 py-3 rounded-2xl border border-white/25">
            <div className="flex items-center gap-2">
              <Flame className="w-6 h-6 text-amber-200 fill-amber-200" />
              <div>
                <span className="text-xs text-amber-100 block">أيام الالتزام</span>
                <span className="text-base font-bold font-mono tabular-nums">{streakDays} أيام متتالية</span>
              </div>
            </div>
          </div>
        </div>

        <div className="absolute -top-12 -left-12 w-48 h-48 rounded-full bg-white/10 pointer-events-none" />
      </div>

      {/* Rewards Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Gift className="w-5 h-5 text-amber-500" />
            <span>اختر مكافأتك المفضلة يا {childName}</span>
          </h3>
          <span className="text-xs text-slate-400 font-medium">كلما أتممت مهامك كسبت نجوماً أكثر!</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {rewards.map((reward) => {
            const canAfford = currentStars >= reward.costStars;
            const diff = reward.costStars - currentStars;

            return (
              <div
                key={reward.id}
                className={`p-5 rounded-3xl border transition-all flex flex-col justify-between ${
                  canAfford
                    ? 'bg-white border-amber-200/80 hover:shadow-lg hover:border-amber-400'
                    : 'bg-slate-50/70 border-slate-200/80 opacity-80'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between mb-3">
                    <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center">
                      {getRewardIcon(reward.icon)}
                    </div>
                    <div className="flex items-center gap-1 px-3 py-1 rounded-xl bg-amber-50 text-amber-700 border border-amber-200 text-xs font-bold font-mono tabular-nums">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                      <span>{reward.costStars} نجمة</span>
                    </div>
                  </div>

                  <h4 className="text-base font-bold text-slate-900 mb-1">
                    {reward.title}
                  </h4>
                  <p className="text-xs text-slate-500 mb-4 line-clamp-2">
                    {reward.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-100">
                  {canAfford ? (
                    <button
                      onClick={() => setSelectedReward(reward)}
                      className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-md shadow-amber-500/20 transition-all flex items-center justify-center gap-2 active:scale-95"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>استبدل بالنجوم الآن!</span>
                    </button>
                  ) : (
                    <div className="w-full py-2 text-center text-xs font-medium text-slate-400 bg-slate-100 rounded-xl">
                      متبقي لك {diff} نجوم ⭐
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Claimed Rewards History */}
      {claimedHistory && claimedHistory.length > 0 && (
        <div className="p-5 rounded-3xl bg-white border border-slate-200 space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-800">
            <History className="w-4 h-4 text-slate-400" />
            <span>سجل الجوائز التي استلمتها مؤخراً</span>
          </div>

          <div className="space-y-2">
            {claimedHistory.map((item, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-100 text-xs"
              >
                <span className="font-bold text-slate-700">{item.title}</span>
                <span className="text-slate-400 font-mono">{item.date}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      {selectedReward && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-pop">
          <div className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl border border-slate-100 text-center">
            <div className="w-16 h-16 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto mb-4">
              <Gift className="w-8 h-8" />
            </div>

            <h3 className="text-lg font-bold text-slate-900 mb-1">
              طلب مكافأة {selectedReward.title}
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              سيتم خصم <strong className="text-amber-600 font-bold">{selectedReward.costStars} نجوم</strong> من رصيدك وطلب استلام المكافأة من ماما أو بابا!
            </p>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setSelectedReward(null)}
                className="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors"
              >
                تراجع
              </button>
              <button
                onClick={() => handleClaim(selectedReward)}
                className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-md shadow-amber-500/25 transition-all"
              >
                تأكيد واستلام 🎉
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
