import confetti from 'canvas-confetti';

// Audio Context Singleton for synthesized web audio
let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export function playStarChime(soundEnabled = true) {
  if (!soundEnabled) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = 'triangle';
  // Pleasant sparkling arpeggio
  osc.frequency.setValueAtTime(587.33, now); // D5
  osc.frequency.exponentialRampToValueAtTime(880, now + 0.08); // A5
  osc.frequency.exponentialRampToValueAtTime(1174.66, now + 0.18); // D6

  gain.gain.setValueAtTime(0.15, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start(now);
  osc.stop(now + 0.45);
}

export function playSuccessFanfare(soundEnabled = true) {
  if (!soundEnabled) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
  const now = ctx.currentTime;

  notes.forEach((freq, idx) => {
    const noteOsc = ctx.createOscillator();
    const noteGain = ctx.createGain();
    const startTime = now + idx * 0.1;
    const duration = idx === notes.length - 1 ? 0.6 : 0.2;

    noteOsc.type = 'sine';
    noteOsc.frequency.setValueAtTime(freq, startTime);

    noteGain.gain.setValueAtTime(0.2, startTime);
    noteGain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);

    noteOsc.connect(noteGain);
    noteGain.connect(ctx.destination);

    noteOsc.start(startTime);
    noteOsc.stop(startTime + duration);
  });
}

export function playTick(soundEnabled = true) {
  if (!soundEnabled) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = 'sine';
  osc.frequency.setValueAtTime(600, now);
  osc.frequency.exponentialRampToValueAtTime(400, now + 0.04);

  gain.gain.setValueAtTime(0.08, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start(now);
  osc.stop(now + 0.05);
}

export function speakArabicPraise(soundEnabled = true) {
  if (!soundEnabled || typeof window === 'undefined' || !('speechSynthesis' in window)) return;
  
  const praises = [
    'أحسنت يا بطل!',
    'ما شاء الله، عمل رائع!',
    'ممتاز جداً!',
    'بارك الله فيك يا ذكي!',
    'رائع، واصل التقدم!'
  ];
  
  const chosen = praises[Math.floor(Math.random() * praises.length)];

  try {
    const utterance = new SpeechSynthesisUtterance(chosen);
    utterance.lang = 'ar-SA';
    utterance.rate = 0.95;
    utterance.pitch = 1.2; // Slightly higher, friendly child pitch
    
    // Find Arabic voice if available
    const voices = window.speechSynthesis.getVoices();
    const arVoice = voices.find(v => v.lang.startsWith('ar'));
    if (arVoice) {
      utterance.voice = arVoice;
    }

    window.speechSynthesis.speak(utterance);
  } catch {
    // Graceful fallback if speech synthesis is blocked
  }
}

export function triggerConfetti() {
  try {
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.7 },
      colors: ['#38bdf8', '#f59e0b', '#10b981', '#ec4899', '#8b5cf6']
    });
  } catch {
    // Ignore fallback
  }
}

export function triggerBigCelebration() {
  try {
    confetti({
      particleCount: 100,
      spread: 100,
      origin: { y: 0.6 },
      colors: ['#fbbf24', '#f43f5e', '#10b981', '#6366f1', '#06b6d4']
    });
  } catch {
    // Ignore fallback
  }
}
