import { AppState, ChildProfile, DailyTask, HomeworkItem, RewardItem } from '../types';

const STORAGE_KEY = 'hero_tasks_kids_app_state_v2';

export const DEFAULT_REWARDS: RewardItem[] = [
  {
    id: 'rew_icecream',
    title: 'مثلجات لذيذة 🍦',
    costStars: 10,
    icon: 'IceCream',
    description: 'تناول الآيس كريم بالنكهة التي تحبها',
    claimedCount: 2
  },
  {
    id: 'rew_tablet',
    title: 'نصف ساعة ألعاب إلكترونية 🎮',
    costStars: 15,
    icon: 'Gamepad2',
    description: 'وقت ممتع ومحدد للألعاب المفضلة',
    claimedCount: 4
  },
  {
    id: 'rew_dinner',
    title: 'اختيار وجبة العشاء المفضلة 🍕',
    costStars: 20,
    icon: 'Utensils',
    description: 'أنت تختار ما نأكله على العشاء اليوم!',
    claimedCount: 1
  },
  {
    id: 'rew_movie',
    title: 'سهرة فيلم كرتون عائلي 🍿',
    costStars: 25,
    icon: 'Film',
    description: 'مشاهدة فيلم كرتون ممتع مع العائلة والفشار',
    claimedCount: 1
  },
  {
    id: 'rew_park',
    title: 'نزهة في الحديقة والملاهي 🎡',
    costStars: 40,
    icon: 'TreePine',
    description: 'رحلة خارجية للعب في الحديقة وركوب الدراجة',
    claimedCount: 0
  },
  {
    id: 'rew_toy',
    title: 'هدية أو لعبة جديدة 🎁',
    costStars: 50,
    icon: 'Gift',
    description: 'شراء لعبة أو كتاب قصص تطلبه بنفسك',
    claimedCount: 0
  }
];

export const DEFAULT_TASKS_AGE_7_10: DailyTask[] = [
  {
    id: 't_fajr',
    title: 'صلاة الفجر وبداية يوم مبارك',
    category: 'prayer_routine',
    iconName: 'Sunrise',
    starsReward: 2,
    completed: true,
    timeOfDay: 'morning',
    description: 'الوضوء والصلاة والشكر لله تعالى'
  },
  {
    id: 't_bed',
    title: 'ترتيب السرير وغرفتي',
    category: 'personal_habits',
    iconName: 'Bed',
    starsReward: 1,
    completed: true,
    timeOfDay: 'morning',
    description: 'ترتيب الغطاء والوسادة بشكل أنيق'
  },
  {
    id: 't_teeth_am',
    title: 'تنظيف الأسنان بالفرشاة',
    category: 'personal_habits',
    iconName: 'Sparkles',
    starsReward: 1,
    completed: true,
    timeOfDay: 'morning',
    description: 'تنظيف الأسنان مرتين يومياً لصحة قوية'
  },
  {
    id: 't_breakfast',
    title: 'تناول فطور صحي ومغذي',
    category: 'personal_habits',
    iconName: 'Apple',
    starsReward: 1,
    completed: true,
    timeOfDay: 'morning',
    description: 'الحليب والبيض والفاكهة لنشاط كامل'
  },
  {
    id: 't_quran_daily',
    title: 'حفظ ومراجعة ورد القرآن الكريم',
    category: 'quran',
    iconName: 'BookOpen',
    starsReward: 3,
    completed: false,
    timeOfDay: 'afternoon',
    description: 'تلاوة وحفظ الآيات المقررة بهدوء وإتقان'
  },
  {
    id: 't_homework',
    title: 'حل الواجبات المدرسية والمذاكرة',
    category: 'study_homework',
    iconName: 'Pencil',
    starsReward: 3,
    completed: false,
    timeOfDay: 'afternoon',
    description: 'إنهاء واجبات اليوم ومراجعة الدروس بتركيز'
  },
  {
    id: 't_school_bag',
    title: 'تجهيز الحقيبة والملابس للغد',
    category: 'helping_home',
    iconName: 'Backpack',
    starsReward: 1,
    completed: false,
    timeOfDay: 'evening',
    description: 'وضع الكتب والأقلام حسب الجدول'
  },
  {
    id: 't_isha',
    title: 'صلاة العشاء وأذكار المساء',
    category: 'prayer_routine',
    iconName: 'Moon',
    starsReward: 2,
    completed: false,
    timeOfDay: 'evening',
    description: 'الصلاة وختام اليوم بنفوس مطمئنة'
  },
  {
    id: 't_sleep_early',
    title: 'أذكار النوم والنوم مبكراً',
    category: 'personal_habits',
    iconName: 'Flame',
    starsReward: 2,
    completed: false,
    timeOfDay: 'evening',
    description: 'قراءة آية الكرسي والنوم لصحة ونشاط الغد'
  }
];

export const DEFAULT_TASKS_AGE_4_6: DailyTask[] = [
  {
    id: 't_young_smile',
    title: 'الاستيقاظ بابتسامة وقول صباح الخير',
    category: 'personal_habits',
    iconName: 'Smile',
    starsReward: 1,
    completed: true,
    timeOfDay: 'morning',
    description: 'إلقاء التحية على ماما وبابا'
  },
  {
    id: 't_young_teeth',
    title: 'غسل الوجه وتنظيف الأسنان',
    category: 'personal_habits',
    iconName: 'Sparkles',
    starsReward: 1,
    completed: true,
    timeOfDay: 'morning',
    description: 'الفرشاة والمعجون اللذيذ'
  },
  {
    id: 't_young_eat',
    title: 'تناول وجبتي بالكامل دون إهدار',
    category: 'personal_habits',
    iconName: 'Apple',
    starsReward: 1,
    completed: true,
    timeOfDay: 'morning',
    description: 'قول بسم الله والأكل باليد اليمنى'
  },
  {
    id: 't_young_quran',
    title: 'ترديد سورة الإخلاص والمعوذتين',
    category: 'quran',
    iconName: 'BookOpen',
    starsReward: 2,
    completed: false,
    timeOfDay: 'afternoon',
    description: 'حفظ كلام الله بصوت جميل'
  },
  {
    id: 't_young_toys',
    title: 'ترتيب وتجميع ألعابي في الصندوق',
    category: 'helping_home',
    iconName: 'Box',
    starsReward: 2,
    completed: false,
    timeOfDay: 'afternoon',
    description: 'إعادة كل لعبة إلى مكانها المناسب'
  },
  {
    id: 't_young_draw',
    title: 'نشاط الرسم أو تلوين الأشكال',
    category: 'fun_activity',
    iconName: 'Palette',
    starsReward: 1,
    completed: false,
    timeOfDay: 'afternoon',
    description: 'تلوين صفحة أو تعلم الحروف والأرقام'
  },
  {
    id: 't_young_story',
    title: 'الاستماع لقصة لطيفة والنوم مبكراً',
    category: 'personal_habits',
    iconName: 'Moon',
    starsReward: 2,
    completed: false,
    timeOfDay: 'evening',
    description: 'قصة جميلة من ماما أو بابا والنوم في موعدي'
  }
];

export const DEFAULT_HOMEWORK_AGE_7_10: HomeworkItem[] = [
  {
    id: 'hw_math',
    title: 'حل تمارين جدول الضرب ص 42',
    subject: 'الرياضيات',
    subjectColor: 'bg-blue-50 text-blue-700 border-blue-200',
    dueDate: 'اليوم',
    status: 'in_progress',
    estimatedMinutes: 20,
    starsReward: 2,
    notes: 'التركيز على جدول 6 و 7'
  },
  {
    id: 'hw_arabic',
    title: 'كتابة درس "الأمانة" بخط النسخ وقراءته',
    subject: 'اللغة العربية',
    subjectColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    dueDate: 'غداً',
    status: 'todo',
    estimatedMinutes: 25,
    starsReward: 3,
    notes: 'الحرص على ضبط الحركات والحروف'
  },
  {
    id: 'hw_science',
    title: 'رسم دورة حياة النبات في دفتر العلوم',
    subject: 'العلوم',
    subjectColor: 'bg-teal-50 text-teal-700 border-teal-200',
    dueDate: 'بعد غد',
    status: 'todo',
    estimatedMinutes: 15,
    starsReward: 2,
    notes: 'تلوين الجذور والساق والأوراق'
  },
  {
    id: 'hw_english',
    title: 'حفظ كلمات الوحدة الثالثة Spelling',
    subject: 'اللغة الإنجليزية',
    subjectColor: 'bg-purple-50 text-purple-700 border-purple-200',
    dueDate: 'غداً',
    status: 'done',
    estimatedMinutes: 15,
    starsReward: 2,
    notes: 'تم تسميع الكلمات لماما بنجاح'
  }
];

export const DEFAULT_HOMEWORK_AGE_4_6: HomeworkItem[] = [
  {
    id: 'hw_young_letters',
    title: 'تتبع حرف (ب) وتلوين بطة 🦆',
    subject: 'حروفي الأولى',
    subjectColor: 'bg-amber-50 text-amber-700 border-amber-200',
    dueDate: 'اليوم',
    status: 'in_progress',
    estimatedMinutes: 15,
    starsReward: 2,
    notes: 'إمساك القلم بشكل مريح'
  },
  {
    id: 'hw_young_numbers',
    title: 'عد التفاحات وكتابة الأرقام 1-5 🍎',
    subject: 'الأرقام والمرح',
    subjectColor: 'bg-rose-50 text-rose-700 border-rose-200',
    dueDate: 'غداً',
    status: 'todo',
    estimatedMinutes: 10,
    starsReward: 2,
    notes: 'نشاط ممتع وسريع'
  }
];

export const INITIAL_CHILDREN: ChildProfile[] = [
  {
    id: 'child_1',
    name: 'كِندَة',
    age: 6,
    avatar: '👧',
    themeColor: 'rose',
    stars: 36,
    streakDays: 4,
    lastCompletedDate: new Date().toISOString().split('T')[0],
    tasks: DEFAULT_TASKS_AGE_7_10,
    homework: DEFAULT_HOMEWORK_AGE_7_10,
    quranProgress: {
      1: { status: 'mastered', memorizedAyahs: 7 },
      114: { status: 'mastered', memorizedAyahs: 6 },
      113: { status: 'mastered', memorizedAyahs: 5 },
      112: { status: 'mastered', memorizedAyahs: 4 },
      111: { status: 'mastered', memorizedAyahs: 5 },
      110: { status: 'mastered', memorizedAyahs: 3 },
      109: { status: 'mastered', memorizedAyahs: 6 },
      108: { status: 'mastered', memorizedAyahs: 3 },
      107: { status: 'reviewing', memorizedAyahs: 7 },
      106: { status: 'reviewing', memorizedAyahs: 4 },
      105: { status: 'memorizing', memorizedAyahs: 3 }
    },
    claimedRewards: [
      { rewardId: 'rew_icecream', date: '2026-09-27', title: 'مثلجات لذيذة 🍦' },
      { rewardId: 'rew_tablet', date: '2026-09-28', title: 'نصف ساعة ألعاب إلكترونية 🎮' }
    ]
  },
  {
    id: 'child_2',
    name: 'عُمَر',
    age: 8,
    avatar: '👦',
    themeColor: 'sky',
    stars: 24,
    streakDays: 3,
    lastCompletedDate: new Date().toISOString().split('T')[0],
    tasks: DEFAULT_TASKS_AGE_7_10,
    homework: DEFAULT_HOMEWORK_AGE_7_10,
    quranProgress: {
      1: { status: 'mastered', memorizedAyahs: 7 },
      114: { status: 'mastered', memorizedAyahs: 6 },
      113: { status: 'mastered', memorizedAyahs: 5 },
      112: { status: 'mastered', memorizedAyahs: 4 }
    },
    claimedRewards: [
      { rewardId: 'rew_tablet', date: '2026-09-28', title: 'نصف ساعة ألعاب إلكترونية 🎮' }
    ]
  }
];

export function loadAppState(): AppState {
  if (typeof window === 'undefined') {
    return {
      children: INITIAL_CHILDREN,
      activeChildId: INITIAL_CHILDREN[0].id,
      rewards: DEFAULT_REWARDS,
      parentPin: '1234',
      soundEnabled: true
    };
  }

  try {
    // Check v2 key first, then fallback to v1
    let raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      raw = localStorage.getItem('hero_tasks_kids_app_state_v1');
    }

    if (!raw) {
      const defaultState: AppState = {
        children: INITIAL_CHILDREN,
        activeChildId: INITIAL_CHILDREN[0].id,
        rewards: DEFAULT_REWARDS,
        parentPin: '1234',
        soundEnabled: true
      };
      saveAppState(defaultState);
      return defaultState;
    }

    const parsed: AppState = JSON.parse(raw);

    // Ensure the primary child is named "كِندَة" if it was the default "عُمَر"
    if (parsed.children && parsed.children.length > 0) {
      const first = parsed.children[0];
      if (first.name === 'عُمَر' || first.name === 'عمر') {
        first.name = 'كِندَة';
        first.avatar = '👧';
      }
    }

    saveAppState(parsed);
    return parsed;
  } catch {
    return {
      children: INITIAL_CHILDREN,
      activeChildId: INITIAL_CHILDREN[0].id,
      rewards: DEFAULT_REWARDS,
      parentPin: '1234',
      soundEnabled: true
    };
  }
}

export function saveAppState(state: AppState): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    console.error('Failed to save state to localStorage', err);
  }
}
