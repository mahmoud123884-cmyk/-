export type TaskTimeOfDay = 'morning' | 'afternoon' | 'evening' | 'anytime';

export type TaskCategory = 
  | 'prayer_routine' 
  | 'study_homework' 
  | 'quran' 
  | 'personal_habits' 
  | 'helping_home' 
  | 'fun_activity';

export interface DailyTask {
  id: string;
  title: string;
  category: TaskCategory;
  iconName: string;
  starsReward: number;
  completed: boolean;
  timeOfDay: TaskTimeOfDay;
  ageGroupMin?: number;
  ageGroupMax?: number;
  description?: string;
}

export type HomeworkStatus = 'todo' | 'in_progress' | 'done';

export interface HomeworkItem {
  id: string;
  title: string;
  subject: string;
  subjectColor: string;
  dueDate: string;
  status: HomeworkStatus;
  estimatedMinutes: number;
  starsReward: number;
  notes?: string;
}

export type SurahStatus = 'not_started' | 'memorizing' | 'reviewing' | 'mastered';

export interface SurahItem {
  number: number;
  name: string;
  englishName: string;
  ayahCount: number;
  juz: number;
  status: SurahStatus;
  memorizedAyahs: number;
  text?: string[];
  audioUrl?: string;
  lastReviewed?: string;
}

export interface RewardItem {
  id: string;
  title: string;
  costStars: number;
  icon: string;
  description: string;
  claimedCount: number;
}

export interface ChildProfile {
  id: string;
  name: string;
  age: number;
  avatar: string;
  themeColor: string;
  stars: number;
  streakDays: number;
  lastCompletedDate: string;
  tasks: DailyTask[];
  homework: HomeworkItem[];
  quranProgress: Record<number, { status: SurahStatus; memorizedAyahs: number }>;
  claimedRewards: { rewardId: string; date: string; title: string }[];
}

export interface AppState {
  children: ChildProfile[];
  activeChildId: string;
  rewards: RewardItem[];
  parentPin: string;
  soundEnabled: boolean;
}
